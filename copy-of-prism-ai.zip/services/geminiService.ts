import { GoogleGenAI, Type, Modality } from "@google/genai";
import { AssessmentQuestion, LearningModule, MindsetAnalysis, GroundingSource, GroundingChunk, PresentationSlide, ProjectIdea, StudentQuizQuestion, Course, InterviewQuestion, Story } from "../types";

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

export const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateLogos = async (prompt: string): Promise<string[]> => {
    const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: prompt,
        config: {
          numberOfImages: 4, // Generate 4 concepts
          outputMimeType: 'image/png',
          aspectRatio: '1:1', // Logos are typically square
        },
    });

    return response.generatedImages.map(img => `data:image/png;base64,${img.image.imageBytes}`);
};

export const generateLearningContent = async (topic: string): Promise<LearningModule[]> => {
    const learningSchema = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                title: { type: Type.STRING, description: "A concise, descriptive title for the learning module section." },
                content: { type: Type.STRING, description: "The detailed content for this section, explaining a key aspect of the topic. Should be at least 2-3 paragraphs long." },
            },
            required: ['title', 'content']
        }
    };
    
    const prompt = `Create a structured, easy-to-understand learning module on the topic of "${topic}". The module should be broken down into 3-4 sections, each with a title and detailed content. Cover the most important aspects of the topic.
    **CRITICAL INSTRUCTION: Your entire response MUST be only the JSON array, perfectly matching the provided schema. Do not include markdown or any other text.**`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: learningSchema,
        },
    });

    const result = JSON.parse(response.text);
    return result as LearningModule[];
};

export const generateImage = async (prompt: string, aspectRatio: '1:1' | '16:9' | '9:16' | '4:3' | '3:4'): Promise<string> => {
    const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: prompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/png',
          aspectRatio: aspectRatio,
        },
    });

    const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
    return `data:image/png;base64,${base64ImageBytes}`;
};

export const editImage = async (base64ImageData: string, mimeType: string, prompt: string): Promise<string> => {
    const imagePart = {
        inlineData: {
            data: base64ImageData,
            mimeType: mimeType,
        },
    };
    const textPart = {
        text: prompt,
    };

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image-preview',
        contents: {
            parts: [imagePart, textPart],
        },
        config: {
            responseModalities: [Modality.IMAGE, Modality.TEXT],
        },
    });
    
    // The response can contain multiple parts, we need to find the image part.
    for (const part of response.candidates[0].content.parts) {
        if (part.inlineData && part.inlineData.mimeType.startsWith('image/')) {
            return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
        }
    }

    throw new Error("The AI did not return an edited image. It might have responded with text only. Try a different prompt.");
};


export const generateVideo = async (prompt: string, image?: { data: string; mimeType: string }) => {
    const request: any = {
        model: 'veo-2.0-generate-001',
        prompt: prompt,
        config: {
            numberOfVideos: 1
        }
    };

    if (image) {
        request.image = {
            imageBytes: image.data,
            mimeType: image.mimeType,
        };
    }
    
    return await ai.models.generateVideos(request);
};

export const pollVideoOperation = async (operation: any) => {
    return await ai.operations.getVideosOperation({ operation: operation });
};

export const generateAssessment = async (context: string): Promise<AssessmentQuestion[]> => {
    const assessmentSchema = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                question: { type: Type.STRING, description: "The question for the quiz." },
                options: {
                    type: Type.ARRAY,
                    description: "A list of 4 multiple-choice options.",
                    items: { type: Type.STRING }
                },
                answer: { type: Type.STRING, description: "The single correct answer, which must be one of the provided options." }
            },
            required: ['question', 'options', 'answer']
        }
    };

    const prompt = `Analyze the following text and generate a multiple-choice quiz with 4-5 questions based on it.
**CRITICAL INSTRUCTION: Your entire response MUST be only the JSON array of questions, perfectly matching the provided schema. Do NOT include any markdown fences (like \`\`\`json), explanatory text, or any other content outside of the JSON array itself.**

Context:
---
${context}
---
`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: assessmentSchema,
        },
    });
    
    const jsonText = response.text.trim();
    // The schema and strict prompt should prevent markdown, but clean just in case.
    const cleanedJson = jsonText.replace(/^```json\n?/, '').replace(/```$/, '');
    
    const result = JSON.parse(cleanedJson);
    return result as AssessmentQuestion[];
};

export const executePythonCode = async (code: string): Promise<string> => {
    const prompt = `You are a Python interpreter. Execute the following Python code and return ONLY the raw stdout output. Do not provide any explanation, markdown formatting, or anything other than the direct output of the code. If there is an error, return the traceback.

Code:
---
${code}
---
`;
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    return response.text;
};

export const debugCode = async (code: string, language: string): Promise<string> => {
    const prompt = `You are an expert code debugger. Analyze the following ${language} code for bugs, errors, or potential issues. Provide a corrected version of the code and a step-by-step explanation of the fixes. Format your response using markdown, with code blocks for the corrected code.

Code:
---
${code}
---
`;
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    return response.text;
};

export const explainCode = async (code: string, language: string): Promise<string> => {
    const prompt = `You are an expert code explainer. Provide a detailed, step-by-step explanation of what the following ${language} code does. Explain the logic, syntax, and purpose of each section. Format your response using markdown.

Code:
---
${code}
---
`;
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    return response.text;
};

export const analyzeMindset = async (answers: string, branch: string): Promise<MindsetAnalysis> => {
    const mindsetSchema = {
        type: Type.OBJECT,
        properties: {
            mindsetProfile: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING, description: "A catchy, descriptive title for this professional mindset profile (e.g., 'The Pragmatic Builder', 'The Creative Visionary')." },
                    description: { type: Type.STRING, description: "A short, insightful paragraph (2-3 sentences) describing the user's core professional mindset, based on their answers." },
                },
                required: ['title', 'description'],
            },
            skillUpPlan: {
                type: Type.OBJECT,
                properties: {
                    focusAreas: {
                        type: Type.ARRAY,
                        description: "A list of 3-4 specific skills or areas the user should focus on for growth.",
                        items: { type: Type.STRING }
                    },
                    recommendedResources: {
                        type: Type.ARRAY,
                        description: "A list of 2-3 specific, actionable resources (e.g., 'Read the book Designing Data-Intensive Applications', 'Contribute to an open-source library like Pandas').",
                        items: { type: Type.STRING }
                    },
                    nextProject: { type: Type.STRING, description: "A suggestion for a small, concrete project the user could build to practice their skills (e.g., 'Build a real-time chat application using WebSockets')." },
                },
                required: ['focusAreas', 'recommendedResources', 'nextProject'],
            }
        },
        required: ['mindsetProfile', 'skillUpPlan']
    };

    const prompt = `Based on the following quiz answers for the field of "${branch}", analyze the user's professional mindset. Generate a profile title, a short description, and a personalized skill-up plan.
**CRITICAL INSTRUCTION: Your entire response MUST be only the JSON object, perfectly matching the provided schema. Do not include markdown or any other text.**

Quiz Answers:
---
${answers}
---
`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: mindsetSchema,
        },
    });

    const result = JSON.parse(response.text);
    return result as MindsetAnalysis;
};

export const groundedSearch = async (prompt: string): Promise<{ text: string; sources: GroundingSource[] }> => {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            tools: [{ googleSearch: {} }],
        },
    });

    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks as GroundingChunk[] | undefined;
    const sources: GroundingSource[] = chunks?.map(chunk => ({
        uri: chunk.web.uri,
        title: chunk.web.title,
    })) || [];

    return {
        text: response.text,
        sources: sources,
    };
};

export const generatePresentationContent = async (topic: string): Promise<PresentationSlide[]> => {
    const presentationSchema = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                title: { type: Type.STRING, description: "The title for this individual presentation slide." },
                content: {
                    type: Type.ARRAY,
                    description: "A list of 3-5 concise bullet points for the slide's content.",
                    items: { type: Type.STRING }
                },
            },
            required: ['title', 'content']
        }
    };

    const prompt = `Generate a structured presentation outline with 5-7 slides for the topic: "${topic}". For each slide, provide a title and 3-5 bullet points.
**CRITICAL INSTRUCTION: Your entire response MUST be only the JSON array, perfectly matching the provided schema. Do not include markdown or any other text.**`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: presentationSchema,
        },
    });

    const result = JSON.parse(response.text);
    return result as PresentationSlide[];
};

export const generateProjectIdeas = async (topic: string): Promise<ProjectIdea[]> => {
    const ideaSchema = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                title: { type: Type.STRING, description: "A creative and concise title for the project idea." },
                description: { type: Type.STRING, description: "A short paragraph (2-4 sentences) describing the project idea, its features, and the potential tech stack." },
            },
            required: ['title', 'description']
        }
    };

    const prompt = `Generate a list of 3-5 creative and distinct project ideas based on the topic or interest: "${topic}".
**CRITICAL INSTRUCTION: Your entire response MUST be only the JSON array, perfectly matching the provided schema. Do not include markdown or any other text.**`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: ideaSchema,
        },
    });

    const result = JSON.parse(response.text);
    return result as ProjectIdea[];
};

export const enhanceResumeText = async (originalText: string): Promise<string> => {
    const prompt = `You are an expert resume writer. Rewrite the following job description bullet points to be more impactful for a resume. Start each bullet point with a strong action verb and focus on quantifiable achievements where possible. Maintain a professional tone and preserve the bulleted or line-by-line format. Return only the rewritten bullet points, with no extra explanation.

Original Text:
---
${originalText}
---
`;
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    return response.text;
};

export const generateStudentQuiz = async (grade: string, subject: string): Promise<StudentQuizQuestion[]> => {
    const quizSchema = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                question: { type: Type.STRING, description: "The quiz question." },
                options: {
                    type: Type.ARRAY,
                    description: "An array of 4 multiple-choice options.",
                    items: { type: Type.STRING }
                },
                answer: { type: Type.STRING, description: "The correct answer, which must exactly match one of the options." },
                explanation: { type: Type.STRING, description: "A brief, clear explanation for why the answer is correct." }
            },
            required: ['question', 'options', 'answer', 'explanation']
        }
    };
    const prompt = `Generate a 5-question multiple-choice quiz for a ${grade} student on the topic of ${subject}. Each question must have 4 options, a correct answer, and a brief explanation.
    **CRITICAL INSTRUCTION: Your entire response MUST be only the JSON array, perfectly matching the provided schema. Do not include markdown or any other text.**`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: quizSchema,
        },
    });
    const result = JSON.parse(response.text);
    return result as StudentQuizQuestion[];
};

export const generateCourseContent = async (topic: string): Promise<Course> => {
  const prompt = `You are an expert instructional designer. Create a comprehensive course outline for the topic: "${topic}". The course should have a main title and be divided into 3-5 modules. For each module, provide a title, a brief description, and use your web search tool to find 2-3 relevant, high-quality YouTube video tutorials. Provide the full YouTube URL and a concise title for each video. **CRITICAL INSTRUCTION: Your entire response MUST be only a single, valid JSON object. Do not include markdown, code fences (\`\`\`json), or any other text outside of the JSON object. The JSON object should have this structure: { "title": string, "modules": [ { "title": string, "description": string, "youtubeLinks": [ { "title": string, "url": string } ] } ] }**`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            tools: [{ googleSearch: {} }],
        },
    });

    try {
        // Attempt to find a JSON object within the response text, even if it's wrapped in markdown
        const match = response.text.match(/\{[\s\S]*\}/);
        if (!match) {
            throw new Error("No valid JSON object found in the AI's response.");
        }
        const result = JSON.parse(match[0]);
        // Basic validation
        if (!result.title || !Array.isArray(result.modules)) {
            throw new Error("Parsed JSON does not match the expected course structure.");
        }
        return result as Course;
    } catch (e) {
        console.error("Failed to parse course content from AI:", e, "Raw response:", response.text);
        throw new Error("The AI returned an invalid format for the course content. Please try again.");
    }
};

export const generateInterviewQuiz = async (topic: string): Promise<InterviewQuestion[]> => {
    const quizSchema = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                question: { type: Type.STRING, description: "An interview-style quiz question for the specified topic." },
                options: {
                    type: Type.ARRAY,
                    description: "An array of 4 multiple-choice options.",
                    items: { type: Type.STRING }
                },
                answer: { type: Type.STRING, description: "The correct answer, which must exactly match one of the options." },
                explanation: { type: Type.STRING, description: "A detailed, step-by-step explanation for why the answer is correct, which is helpful for learning." }
            },
            required: ['question', 'options', 'answer', 'explanation']
        }
    };
    const prompt = `Generate a 5-question multiple-choice quiz for interview preparation on the topic of "${topic}". The questions should be of a standard difficulty for a job interview. Each question must have 4 options, a correct answer, and a detailed explanation.
    **CRITICAL INSTRUCTION: Your entire response MUST be only the JSON array, perfectly matching the provided schema. Do not include markdown or any other text.**`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: quizSchema,
        },
    });
    const result = JSON.parse(response.text);
    return result as InterviewQuestion[];
};

export const generateStory = async (prompt: string): Promise<Story> => {
    // Step 1: Generate the story text and image prompts
    const storyTextSchema = {
        type: Type.OBJECT,
        properties: {
            title: { type: Type.STRING, description: "A creative and engaging title for the story." },
            scenes: {
                type: Type.ARRAY,
                description: "An array of 3-4 scenes that make up the story.",
                items: {
                    type: Type.OBJECT,
                    properties: {
                        paragraph: { type: Type.STRING, description: "A paragraph of the story for this scene." },
                        imagePrompt: { type: Type.STRING, description: "A short, visually descriptive prompt for an AI image generator that captures this scene. e.g., 'A brave knight in shining armor facing a friendly, green dragon in a sunlit forest.'" }
                    },
                    required: ["paragraph", "imagePrompt"]
                }
            }
        },
        required: ["title", "scenes"]
    };

    const storyPrompt = `Create a short, illustrated story based on the following idea: "${prompt}". Generate a title and 3-4 scenes. For each scene, write one paragraph of the story and a visually descriptive prompt for an AI image generator.
    **CRITICAL INSTRUCTION: Your entire response MUST be only the JSON object, perfectly matching the provided schema. Do not include markdown or any other text.**`;
    
    const textResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: storyPrompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: storyTextSchema,
        },
    });

    const storyStructure = JSON.parse(textResponse.text);

    // Step 2: Generate an image for each scene
    const illustratedScenes = await Promise.all(
        storyStructure.scenes.map(async (scene: { paragraph: string; imagePrompt: string }) => {
            const imageResponse = await ai.models.generateImages({
                model: 'imagen-4.0-generate-001',
                prompt: scene.imagePrompt,
                config: {
                  numberOfImages: 1,
                  outputMimeType: 'image/png',
                  aspectRatio: '16:9',
                },
            });
            const imageUrl = `data:image/png;base64,${imageResponse.generatedImages[0].image.imageBytes}`;
            return {
                paragraph: scene.paragraph,
                imageUrl: imageUrl,
            };
        })
    );

    return {
        title: storyStructure.title,
        scenes: illustratedScenes,
    };
};