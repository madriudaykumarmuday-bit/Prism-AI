
import React, { useState, useRef, KeyboardEvent, ChangeEvent, useEffect } from 'react';
import { Icon } from './Icon';
import { useSpeechRecognition } from '../hooks/useSpeechRecognition';

interface MessageInputProps {
  onSend: (message: string, file: File | null) => void;
  disabled: boolean;
  isWebSearchEnabled: boolean;
  onWebSearchToggle: () => void;
}

const AttachmentPreview: React.FC<{ file: File; onRemove: () => void }> = ({ file, onRemove }) => {
    const objectUrl = React.useMemo(() => URL.createObjectURL(file), [file]);
    
    useEffect(() => {
        // Clean up object URL when component unmounts
        return () => URL.revokeObjectURL(objectUrl);
    }, [objectUrl]);

    return (
        <div className="relative inline-block bg-black/30 p-2 rounded-lg mr-2">
            <img 
                src={objectUrl} 
                alt={file.name} 
                className="w-16 h-16 object-cover rounded-md"
            />
            <button 
                onClick={onRemove} 
                className="absolute -top-2 -right-2 bg-gray-800/80 backdrop-blur-sm rounded-full text-gray-400 hover:text-white"
                aria-label="Remove attachment"
            >
                <Icon as="x-circle" className="w-6 h-6" />
            </button>
        </div>
    );
};


export const MessageInput: React.FC<MessageInputProps> = ({ onSend, disabled, isWebSearchEnabled, onWebSearchToggle }) => {
  const [text, setText] = useState('');
  const [attachment, setAttachment] = useState<File | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const {
    isListening,
    transcript,
    startListening,
    stopListening,
    hasRecognitionSupport,
  } = useSpeechRecognition();

  const adjustTextareaHeight = () => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  };

  useEffect(() => {
    if (transcript) {
        setText(prevText => prevText ? `${prevText} ${transcript}` : transcript);
    }
  }, [transcript]);

  useEffect(() => {
    adjustTextareaHeight();
  }, [text]);

  const handleSend = () => {
    if ((text.trim() || attachment) && !disabled) {
      onSend(text, attachment);
      setText('');
      setAttachment(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
       if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };
  
  const handleChange = (e: ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
  };

  const handleMicClick = () => {
    if (isListening) {
        stopListening();
    } else {
        startListening();
    }
  }
  
  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        setAttachment(file);
    }
  }
  
  const removeAttachment = () => {
    setAttachment(null);
    if (fileInputRef.current) {
        fileInputRef.current.value = '';
    }
  }

  return (
    <div className="bg-black/20 backdrop-blur-md border border-white/10 rounded-lg p-2 flex flex-col">
       {attachment && (
        <div className="p-2 border-b border-white/10 mb-2">
            <AttachmentPreview file={attachment} onRemove={removeAttachment} />
        </div>
      )}
      <div className="flex items-end">
        <button
            onClick={onWebSearchToggle}
            disabled={disabled}
            className={`p-2 rounded-md transition-colors focus:outline-none ${isWebSearchEnabled ? 'text-cyan-400 bg-cyan-900/50' : 'text-gray-400 hover:text-white'}`}
            aria-label="Toggle web search"
            title={isWebSearchEnabled ? "Web search is ON" : "Web search is OFF"}
        >
            <Icon as="globe" className="w-5 h-5" />
        </button>
        <textarea
            ref={textareaRef}
            value={text}
            onChange={handleChange}
            onKeyDown={handleKeyDown}
            placeholder="Type your message..."
            className="flex-grow bg-transparent text-white placeholder-gray-400 focus:outline-none resize-none overflow-y-auto max-h-48 px-2"
            rows={1}
            disabled={disabled}
        />
        <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange}
            className="hidden"
            accept="image/*"
        />
        <button
            onClick={() => fileInputRef.current?.click()}
            disabled={disabled}
            className="p-2 rounded-md text-gray-400 hover:text-white transition-colors focus:outline-none"
            aria-label="Attach file"
        >
            <Icon as="paperclip" className="w-5 h-5" />
        </button>
        {hasRecognitionSupport && (
            <button
                onClick={handleMicClick}
                disabled={disabled}
                className={`p-2 rounded-md ${isListening ? 'text-red-500 animate-pulse' : 'text-gray-400'} hover:text-white transition-colors focus:outline-none`}
                aria-label={isListening ? "Stop listening" : "Start listening"}
            >
                <Icon as="microphone" className="w-5 h-5" />
            </button>
        )}
        <button
            onClick={handleSend}
            disabled={disabled || (!text.trim() && !attachment)}
            className="ml-2 p-2 rounded-md bg-cyan-600 text-white disabled:bg-gray-600 disabled:cursor-not-allowed hover:bg-cyan-700 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-cyan-500"
            aria-label="Send message"
        >
            <Icon as="send" className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};