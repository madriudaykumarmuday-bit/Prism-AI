
import React from 'react';
import { Icon } from './Icon';

interface SidebarProps {
  startNewChat: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ startNewChat }) => {
  return (
    <aside className="w-64 bg-gray-800 p-4 flex-col border-r border-gray-700 flex-shrink-0 hidden md:flex">
      <div className="flex-grow">
        {/* Chat history can be added here in the future */}
      </div>
      <div className="mt-auto">
        <button
          onClick={startNewChat}
          className="flex items-center gap-2 w-full px-3 py-2 text-sm font-medium text-gray-300 bg-gray-900/50 border border-gray-700 rounded-md hover:bg-gray-700 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500"
          aria-label="Start new chat"
        >
          <Icon as="plus" className="w-5 h-5" />
          New Chat
        </button>
      </div>
    </aside>
  );
};
