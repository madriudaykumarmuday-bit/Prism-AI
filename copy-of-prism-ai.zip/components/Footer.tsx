
import React from 'react';

export const Footer: React.FC = () => {
  return (
    <div className="fixed bottom-4 right-4 text-xs text-gray-400 z-10 no-print bg-transparent">
      Developed By Madri Uday kumar
    </div>
  );
};