import React, { useState, useEffect } from 'react';
import Modal from './Modal';
import Loader from './Loader';
import { analyzeMindset, groundedSearch } from '../services/geminiService';
import { MindsetAnalysis, GroundingSource } from '../types';

interface MindsetAnalyzerProps {
  isOpen: boolean;
  onClose: () => void;
}

type QuizState = 'branch_selection' | 'taking' | 'analyzing' | 'results';
type ViewState = 'quiz' | 'search';

const quizData = {
  "CSE": [
    { question: "When optimizing code, what do you prioritize?", options: ["Readability and maintainability", "Raw execution speed", "Minimizing memory usage", "Algorithmic elegance and simplicity"] },
    { question: "You need to implement a new feature. What's your first step?", options: ["Write the user story and define acceptance criteria", "Design the API endpoints and data schema", "Build the UI components first", "Spike a proof-of-concept to validate the approach"] },
    { question: "How do you approach learning a new programming language?", options: ["Read the official documentation thoroughly", "Build a small, complete project from scratch", "Follow a guided tutorial series", "Contribute to an open-source project using it"] },
    { question: "What aspect of a large software system interests you most?", options: ["The user interface and experience", "The database architecture and data flow", "The deployment and scaling infrastructure (CI/CD, Kubernetes)", "The core business logic and algorithms"] },
    { question: "A critical bug is reported in production. What's your immediate priority?", options: ["Writing a failing test case to replicate it", "Patching it live as quickly as possible", "Informing stakeholders about the potential impact", "Performing a root cause analysis before touching code"] },
    { question: "When choosing a technology stack for a new project, what's your main driver?", options: ["My personal familiarity and expertise", "The long-term scalability and maintainability", "The size and activity of the community/ecosystem", "Cutting-edge performance and modern features"] },
    { question: "How do you feel about code reviews?", options: ["A crucial step for quality and knowledge sharing", "A necessary but time-consuming process", "A chance to show off clever solutions", "An opportunity to find flaws in others' code"] },
    { question: "What's your preferred way to manage technical debt?", options: ["Address it immediately as it arises", "Schedule dedicated 'refactor' sprints", "Only fix it when it directly blocks a new feature", "Document it and hope to get to it later"] },
    { question: "You're faced with a complex problem you've never seen before. You...", options: ["Break it down into the smallest possible pieces first", "Search for existing libraries or solutions", "Draw diagrams on a whiteboard to visualize it", "Start coding a brute-force solution to understand it better"] },
    { question: "What is the ideal role of documentation in a project?", options: ["It should be comprehensive and cover every detail", "It should be minimal; the code should be self-documenting", "It should focus on high-level architecture and 'why'", "It should be auto-generated from code comments"] }
  ],
  "AI": [
    { question: "When starting a new ML project, what is the most critical first step?", options: ["Choosing the most advanced model architecture", "Extensive exploratory data analysis (EDA)", "Setting up a robust data pipeline", "Defining the business problem and success metrics"] },
    { question: "Your model's performance is plateauing. What's your next move?", options: ["Spend more time on feature engineering", "Try a completely different type of model", "Collect more (or better) data", "Fine-tune hyperparameters for another 12 hours"] },
    { question: "How do you view the importance of model explainability (XAI)?", options: ["It's a top priority for building trust and debugging", "It's a 'nice-to-have' but performance is more important", "It depends entirely on the use case (e.g., medical vs. recommendation)", "It's mainly for academic purposes"] },
    { question: "What is your primary tool for debugging a neural network?", options: ["Visualizing activations and gradients", "Printing tensor shapes and values", "Using a formal debugger (e.g., pdb)", "Analyzing the loss curve and metrics over time"] },
    { question: "You have a small, high-quality dataset. Which approach do you favor?", options: ["Transfer learning from a large pre-trained model", "Complex data augmentation techniques", "Using a simpler, less data-hungry model", "Trying to gather more data, even if lower quality"] },
    { question: "What's your opinion on the latest 'State-of-the-Art' (SOTA) model on arXiv?", options: ["I'm immediately trying to implement and test it", "I'm skeptical until it's been reproduced by others", "I'll read the paper to understand the core concepts", "I'll wait until it's available in a major library"] },
    { question: "When deploying an AI model, what is your biggest non-technical concern?", options: ["Ethical implications and potential bias", "Computational cost and latency", "Monitoring for data drift and performance degradation", "User adoption and trust"] },
    { question: "Which area of AI research excites you the most right now?", options: ["Large Language Models (LLMs) and generative AI", "Reinforcement learning and robotics", "Computer vision and multimodal systems", "Causal inference and structured reasoning"] },
    { question: "A stakeholder asks for 100% accuracy. You respond by...", options: ["Explaining the concept of irreducible error and setting realistic expectations", "Trying to get as close as possible with extensive tuning", "Questioning if the metric itself is correct for the business problem", "Reframing the problem to one where 100% is theoretically possible"] },
    { question: "How do you stay updated in the fast-paced field of AI?", options: ["Reading research papers daily", "Following key researchers on social media", "Watching conference talks and tutorials", "Building and experimenting with new models and tools"] }
  ],
  "DS": [
    { question: "You're given a new dataset. What's your immediate action?", options: ["Generate summary statistics (mean, median, std dev)", "Create visualizations to spot trends and outliers", "Check for missing values and data quality issues", "Formulate a hypothesis to test with the data"] },
    { question: "How do you communicate your findings to non-technical stakeholders?", options: ["A detailed Jupyter notebook with all the code", "An interactive dashboard (e.g., Tableau, Power BI)", "A concise slide deck with key charts and insights", "A formal written report with statistical proofs"] },
    { question: "What's more important for a business-facing data science project?", options: ["A model with 99% accuracy that's hard to interpret", "A model with 95% accuracy that's easily explainable", "A beautifully designed and compelling data visualization", "A robust data pipeline that ensures data freshness"] },
    { question: "Which statement best describes your approach to data?", options: ["'The data will speak for itself'", "'All models are wrong, but some are useful'", "'Without data, you're just another person with an opinion'", "'The goal is to turn data into information, and information into insight'"] },
    { question: "The business wants a predictive model, but the data quality is poor. You...", options: ["Build the best model possible and highlight the data caveats", "Refuse to build a model until the data collection process is fixed", "Focus on descriptive analytics to provide value first", "Create a data cleaning pipeline as the main project"] },
    { question: "What is your favorite part of the data science lifecycle?", options: ["The 'aha!' moment during exploratory data analysis", "The mathematical rigor of modeling and statistics", "The engineering challenge of deploying a model to production", "The impact of presenting insights that drive decisions"] },
    { question: "When A/B testing, a statistically significant result is found. What's next?", options: ["Recommend rolling out the feature immediately", "Segment the results to see impacts on different user groups", "Run the test longer to ensure it's not a novelty effect", "Investigate the 'why' behind the result"] },
    { question: "How do you balance statistical rigor with speed of delivery?", options: ["Rigor is non-negotiable, even if it's slower", "Start with 'good enough' heuristics and iterate", "Use automated tools (AutoML) to speed up modeling", "Timebox the analysis and present the best findings"] },
    { question: "Which tool do you reach for first for data manipulation?", options: ["Pandas in a Jupyter Notebook", "SQL queries directly against the database", "A GUI-based tool like Tableau Prep", "R with dplyr"] },
    { question: "'Correlation does not imply causation.' What does this mean to you in practice?", options: ["It's the first principle; I'm always looking for confounders", "It's a useful reminder not to overstate findings", "It's a reason to always push for controlled experiments", "It's a textbook phrase with limited relevance"] }
  ],
   "Cybersecurity": [
    { question: "What does the 'CIA' triad stand for in information security?", options: ["Confidentiality, Integrity, Availability", "Communication, Integration, Authorization", "Control, Investigate, Audit", "Cyber, Intelligence, Agency"] },
    { question: "A phishing attack is an attempt to...", options: ["Overload a server with traffic", "Steal sensitive information like passwords and credit card numbers", "Encrypt a user's files and demand a ransom", "Physically break into a facility"] },
    { question: "Which of the following is the best way to protect against malware?", options: ["Using a strong, unique password", "Disabling your firewall", "Regularly updating your antivirus software and operating system", "Only visiting websites you know"] },
    { question: "What is a 'Zero-Day' vulnerability?", options: ["A vulnerability that has been known for less than 24 hours", "A flaw in software that is unknown to the vendor and has no patch", "A vulnerability that only affects systems on their first day of use", "A security flaw that is easy to exploit"] },
    { question: "Multi-Factor Authentication (MFA) adds a layer of security by requiring...", options: ["A longer, more complex password", "The user to solve a puzzle", "Something you know, something you have, or something you are", "Answering a security question"] },
    { question: "What is the primary purpose of a firewall?", options: ["To scan for viruses", "To monitor and control incoming and outgoing network traffic", "To back up your data", "To encrypt your internet connection"] },
    { question: "You receive an unsolicited email with a suspicious attachment. What should you do?", options: ["Open the attachment to see what it is", "Reply to the sender and ask if it's legitimate", "Delete the email immediately without opening the attachment", "Forward it to your IT department's spam analysis address"] },
    { question: "In cybersecurity, what is 'social engineering'?", options: ["Hacking into social media accounts", "The technical process of engineering a secure network", "Manipulating people into divulging confidential information", "Designing secure social platforms"] },
    { question: "A DDoS attack aims to...", options: ["Steal data from a server", "Make an online service unavailable by overwhelming it with traffic", "Install a virus on a user's computer", "Deface a website"] },
    { question: "What is the best practice for password management?", options: ["Using the same strong password everywhere", "Writing passwords down on a sticky note", "Using a reputable password manager", "Changing your password every week"] }
  ],
  "Cloud Computing": [
    { question: "Which cloud service model provides virtualized computing resources over the internet (e.g., VMs, storage, networks)?", options: ["SaaS (Software as a Service)", "PaaS (Platform as a Service)", "IaaS (Infrastructure as a Service)", "FaaS (Function as a Service)"] },
    { question: "Amazon Web Services (AWS), Microsoft Azure, and Google Cloud Platform (GCP) are examples of...", options: ["Private Clouds", "Hybrid Clouds", "Public Clouds", "Community Clouds"] },
    { question: "What is the primary advantage of 'auto-scaling' in the cloud?", options: ["It reduces the initial cost of setup", "It automatically adjusts capacity to maintain performance and minimize cost", "It encrypts all data automatically", "It provides a user-friendly dashboard"] },
    { question: "'Serverless computing' means...", options: ["You don't need servers to run a website", "The cloud provider manages the servers, and you only pay for execution time", "Your code runs directly on the client's browser", "There is no physical hardware involved"] },
    { question: "What is a 'Virtual Private Cloud' (VPC)?", options: ["A cloud that is open to the public", "A logically isolated section of a public cloud where you can launch resources", "A physical data center owned by your company", "A type of cloud storage"] },
    { question: "When a company uses a mix of on-premises infrastructure and a public cloud, it's called a...", options: ["Multi-Cloud", "Hybrid Cloud", "Private Cloud", "Community Cloud"] },
    { question: "Which of the following is a key benefit of cloud computing?", options: ["Higher latency", "Capital expenditure on hardware", "Elasticity and scalability", "The need to manage physical servers"] },
    { question: "In the context of cloud storage, what does 'durability' refer to?", options: ["How quickly you can access your data", "The ability to prevent accidental deletion or corruption of data over a long period", "The physical toughness of the storage drives", "The cost per gigabyte"] },
    { question: "'Load Balancing' in the cloud is used to...", options: ["Distribute incoming network traffic across multiple servers", "Ensure all servers are using the same amount of electricity", "Backup data to different regions", "Manage user authentication"] },
    { question: "Which cloud model involves offering licensed software to customers for use as a service on demand (e.g., Google Workspace, Salesforce)?", options: ["IaaS", "PaaS", "SaaS", "FaaS"] }
  ],
  "UI/UX Design": [
    { question: "What is the primary goal of User Experience (UX) design?", options: ["To make the product look visually appealing", "To enhance user satisfaction by improving usability, accessibility, and pleasure in the interaction", "To write clean and efficient code for the user interface", "To create a detailed style guide"] },
    { question: "'A/B Testing' is a method used to...", options: ["Compare two versions of a web page or app to see which one performs better", "Test the backend and frontend of an application", "Check for accessibility compliance", "Ensure the design looks good on both Android and iOS"] },
    { question: "In design, what does the term 'heuristic evaluation' refer to?", options: ["A usability inspection method where experts judge an interface against recognized usability principles", "User testing with a large group of people", "Creating a customer journey map", "A final check of the visual design before launch"] },
    { question: "What is the purpose of creating user personas?", options: ["To have fictional characters for a story", "To replace the need for real user testing", "To create reliable and realistic representations of your key audience segments", "To decide on the color palette for the application"] },
    { question: "The 'F-Shaped Pattern' in user reading behavior on the web suggests that...", options: ["Users read every word on the page", "Users' eyes scan in a pattern that resembles the letter F", "Users prefer designs with a lot of text", "Users find content in the footer first"] },
    { question: "What is a 'wireframe' in the design process?", options: ["A high-fidelity mockup with final colors and images", "A basic visual guide that represents the skeletal framework of a website or app", "A clickable prototype", "The final HTML and CSS code"] },
    { question: "'Hick's Law' states that the time it takes to make a decision...", options: ["Decreases with the number of choices", "Increases with the number and complexity of choices", "Is the same for all users", "Depends on the visual appeal of the choices"] },
    { question: "What is the main difference between UI and UX design?", options: ["They are the same thing", "UI is focused on the visual look and feel, while UX is focused on the overall user journey and feel", "UI is for mobile apps, UX is for websites", "UI designers code, UX designers do research"] },
    { question: "Why is 'accessibility' (a11y) important in design?", options: ["It's a trend that makes designs look modern", "It ensures that people with disabilities can use the product", "It helps the website rank higher in search engines", "It is only required for government websites"] },
    { question: "A 'call to action' (CTA) is designed to...", options: ["Provide contact information", "Prompt an immediate response or encourage a sale", "Display a legal disclaimer", "Explain the company's mission"] }
  ],
  "ECE": [
    { question: "When designing a circuit, what is your main concern?", options: ["Minimizing power consumption", "Maximizing processing speed", "Ensuring signal integrity", "Reducing the physical footprint (size)"] },
    { question: "You're debugging a hardware/software interface. Where do you start?", options: ["With an oscilloscope on the physical pins", "In the driver-level software", "By reviewing the component's datasheet again", "By simulating the interaction in a tool like ModelSim"] },
    { question: "Which programming language are you most comfortable with for embedded systems?", options: ["Bare-metal C", "C++ with object-oriented principles", "MicroPython/CircuitPython for rapid prototyping", "VHDL/Verilog for FPGA development"] },
    { question: "What's your favorite part of an electronics project?", options: ["The initial schematic design and simulation", "The PCB layout and routing puzzle", "Soldering the components and initial power-on", "Writing the firmware that brings it to life"] },
    { question: "You need to choose a microcontroller. What's the deciding factor?", options: ["The richness of its peripheral set (ADC, PWM, I2C)", "Ultra-low power consumption", "Availability of a good SDK and dev tools", "Raw processing power (clock speed, core type)"] },
    { question: "What aspect of wireless communication is most interesting to you?", options: ["Antenna design and RF theory", "Modulation schemes and digital signal processing (DSP)", "Network protocols and data link layer", "Low-power protocols like BLE or LoRaWAN"] },
    { question: "Your new PCB doesn't work. What's your first debugging step?", options: ["Visually inspect all solder joints with a microscope", "Check all power rails with a multimeter", "Connect a JTAG/SWD debugger to the CPU", "Blame the fabrication house"] },
    { question: "How do you feel about FPGAs vs. Microcontrollers?", options: ["FPGAs for high-speed parallel tasks, MCUs for everything else", "MCUs are simpler and faster to develop for", "FPGAs offer ultimate flexibility but are complex", "I prefer to use the tool I know best"] },
    { question: "When reading a component datasheet, which section do you read first?", options: ["The pinout diagram", "The electrical characteristics (voltage, current)", "The register maps for peripherals", "The example application circuits"] },
    { question: "What is the most challenging aspect of mixed-signal design?", options: ["Preventing digital noise from coupling into the analog section", "Matching component tolerances in the analog domain", "Choosing the right ADC/DAC for the application", "Simulating the entire system accurately"] }
  ],
  "EEE": [
    { question: "What aspect of power systems fascinates you the most?", options: ["Renewable energy integration and grid stability", "High-voltage transmission and protection schemes", "Power electronics and motor drives", "Smart grid technologies and demand-side management"] },
    { question: "You're designing a control system. What is your primary goal?", options: ["Fastest possible response time", "Maximum stability and robustness to disturbances", "Zero steady-state error", "Minimizing energy usage"] },
    { question: "When working with electrical machinery, what is most important?", options: ["Efficiency and performance calculations", "Safety protocols and procedures", "The underlying electromagnetic principles", "The control and automation aspects"] },
    { question: "Which software tool is most indispensable to your work?", options: ["MATLAB/Simulink for simulation", "A SPICE-based circuit simulator (e.g., LTspice)", "An IDE for programming microcontrollers", "Power system analysis software (e.g., ETAP)"] },
    { question: "When analyzing a power grid, what problem is most compelling?", options: ["Solving load flow equations", "Transient stability analysis after a fault", "Economic dispatch and unit commitment", "Harmonic analysis and power quality"] },
    { question: "You are designing a power converter. What do you spend the most time on?", options: ["Selecting the right topology", "Designing the magnetic components (inductor)", "The feedback control loop for regulation", "PCB layout to minimize EMI"] },
    { question: "The future of electric vehicles depends most on...?", options: ["Breakthroughs in battery chemistry and density", "Widespread, ultra-fast charging infrastructure", "Smarter vehicle-to-grid (V2G) integration", "More efficient electric motors and inverters"] },
    { question: "What is the biggest challenge in integrating renewables into the grid?", options: ["Its intermittency and unpredictability", "The need for large-scale energy storage", "The power electronics interface (inverters)", "The geographical distance from load centers"] },
    { question: "If you could improve one aspect of today's electrical systems, it would be...", options: ["Overall energy efficiency", "Grid reliability and resilience", "The adoption of DC microgrids", "Cybersecurity of grid control systems (SCADA)"] },
    { question: "What is your preferred method for solving complex circuit problems?", options: ["Nodal or Mesh analysis by hand", "Building a SPICE simulation", "Using Laplace transforms to work in the s-domain", "Applying network theorems like Thevenin's or Norton's"] }
  ],
  "CIVIL": [
    { question: "What is the most critical factor in the design of a large structure?", options: ["The properties of the materials used", "The accuracy of the load calculations", "The geotechnical survey of the site", "Compliance with all building codes and standards"] },
    { question: "A construction project is behind schedule. What's your first action?", options: ["Authorize overtime for the crews", "Re-evaluate the critical path and re-allocate resources", "Negotiate a new deadline with the client", "Look for opportunities to use pre-fabricated components"] },
    { question: "Which technology has the most potential to transform civil engineering?", options: ["Building Information Modeling (BIM)", "Drones for surveying and inspection", "New, sustainable building materials", "AI for generative design and optimization"] },
    { question: "What do you consider the biggest challenge in your field?", options: ["Ensuring public safety above all else", "Balancing project costs with quality and longevity", "Minimizing environmental impact", "Adapting infrastructure for climate change"] },
    { question: "When choosing a material, what's more important: sustainability or initial cost?", options: ["Lifecycle cost, including maintenance and sustainability, is key", "Initial cost is almost always the deciding factor", "Sustainability, even if it costs more upfront", "It depends entirely on the client's priorities"] },
    { question: "Which area of civil engineering are you most passionate about?", options: ["Structural engineering (buildings, bridges)", "Geotechnical engineering (foundations, soil mechanics)", "Transportation engineering (highways, traffic flow)", "Water resources engineering (hydrology, hydraulics)"] },
    { question: "A new, innovative construction method is proposed. Your reaction is...", options: ["Excitement to try it on a pilot project", "Skepticism until it's proven and in the building codes", "To conduct a thorough risk and cost-benefit analysis", "To see how competitors are using it first"] },
    { question: "What's the most important software in your toolkit?", options: ["CAD software like AutoCAD", "BIM software like Revit", "Structural analysis software like SAP2000", "Project management software like Primavera"] },
    { question: "What does 'resilience' mean to you in infrastructure design?", options: ["Ability to withstand extreme events like earthquakes", "Ability to recover quickly after a disruption", "Ability to adapt to long-term changes like sea-level rise", "All of the above"] },
    { question: "When visiting a new city, what are you most likely to notice?", options: ["The design and condition of its bridges", "The efficiency of its public transit system", "The layout of its water and drainage systems", "The unique architecture of its landmark buildings"] }
  ],
  "MECH": [
    { question: "When designing a mechanical part, what is your starting point?", options: ["A series of hand-drawn sketches", "A 3D CAD model", "A set of mathematical equations governing the physics", "Researching existing designs and patents"] },
    { question: "Which type of analysis is most crucial for your work?", options: ["Finite Element Analysis (FEA) for stress and strain", "Computational Fluid Dynamics (CFD) for fluid flow", "Thermodynamic analysis for heat transfer", "Kinematic analysis for motion and linkages"] },
    { question: "You need to select a material. What's the deciding factor?", options: ["Strength-to-weight ratio", "Cost and manufacturability", "Resistance to corrosion or fatigue", "Thermal properties"] },
    { question: "What is the most satisfying part of the engineering process for you?", options: ["The creativity of the initial design phase", "The precision of the simulation and analysis", "The hands-on process of prototyping and manufacturing", "Seeing the final product perform as designed"] },
    { question: "How do you approach 'Design for Manufacturability' (DFM)?", options: ["It's a primary constraint from the very beginning", "It's something to optimize after the core design is proven", "I consult with manufacturing engineers throughout the process", "I rely on my experience of what's possible to make"] },
    { question: "What area of thermodynamics do you find most applicable?", options: ["Heat transfer in electronics cooling", "Power cycles for engines and power generation", "HVAC and refrigeration systems", "Fluid dynamics and compressible flow"] },
    { question: "Your prototype fails during testing. What's your reaction?", options: ["Frustration, followed by a methodical failure analysis", "Excitement, a failure is a learning opportunity", "Immediately start redesigning the failed component", "Double-check the test setup and sensor data first"] },
    { question: "What is the role of hand calculations in the age of simulation software?", options: ["Essential for sanity-checking simulation results", "Useful for first-order approximations at the concept stage", "Largely obsolete, simulation is more accurate", "A good academic exercise but rarely used in industry"] },
    { question: "What's your favorite CAD software feature?", options: ["Powerful parametric modeling and relations", "Integrated simulation and FEA tools", "Generative design and topology optimization", "Advanced surfacing for complex shapes"] },
    { question: "Robotics and automation are...", options: ["The most exciting application of mechanical engineering", "A complex field requiring multidisciplinary skills", "Primarily a controls and software problem", "A way to enhance manufacturing and precision"] }
  ],
  "B.Pharm": [
    { question: "What aspect of pharmacy practice is most appealing to you?", options: ["Direct patient counseling and interaction", "The science of drug formulation and development", "Managing the business and operations of a pharmacy", "Working in a hospital setting with a clinical team"] },
    { question: "A patient questions the side effects of a new medication. You...", options: ["Provide a detailed, technical explanation", "Use simple analogies to explain the risk vs. benefit", "Give them the printed patient information leaflet", "Reassure them and suggest they speak with their doctor"] },
    { question: "How do you stay updated with new drugs and treatment guidelines?", options: ["Attending seminars and continuing education programs", "Reading medical and pharmaceutical journals regularly", "Relying on information from pharmaceutical representatives", "Learning from senior colleagues and peers"] },
    { question: "What is the most critical skill for a pharmacist?", options: ["Meticulous attention to detail", "Empathetic communication skills", "Strong business acumen", "In-depth pharmacological knowledge"] },
    { question: "You notice a potential prescription error from a doctor. What's your first step?", options: ["Dispense the medication as written", "Refuse to fill the prescription", "Contact the doctor directly to clarify", "Ask the patient for more information about their condition"] },
    { question: "Which career path in pharmacy interests you most?", options: ["Community Pharmacy (Retail)", "Industrial Pharmacy (Manufacturing, R&D)", "Hospital or Clinical Pharmacy", "Pharmaceutical Marketing and Sales"] },
    { question: "How do you view the role of technology in pharmacy?", options: ["A tool to improve efficiency and reduce errors", "A potential barrier to patient interaction", "A way to provide new services like tele-pharmacy", "A complex requirement for regulatory compliance"] },
    { question: "When dealing with a difficult or anxious patient, your primary approach is...", options: ["To be firm and stick to the facts", "To be patient, listen, and show empathy", "To work as quickly as possible to end the interaction", "To refer them to a senior pharmacist"] },
    { question: "What's your opinion on alternative medicine?", options: ["It has no place in evidence-based pharmacy", "It can be a useful complement for some patients", "I am skeptical but open-minded", "I would only discuss it if a patient asks"] },
    { question: "What is the biggest challenge facing pharmacy today?", options: ["Increasing competition and pressure on margins", "The expanding role of pharmacists as healthcare providers", "The complexity of new drug therapies", "Keeping up with changing regulations"] }
  ],
  "D.Pharm": [
    { question: "What do you enjoy most about working in a pharmacy?", options: ["Organizing and managing inventory", "Assisting the pharmacist with dispensing", "Interacting with customers and helping them find products", "The structured and process-oriented nature of the work"] },
    { question: "A customer asks for advice on a minor ailment. You...", options: ["Give them your best personal advice", "Immediately refer them to the pharmacist", "Show them the relevant section of over-the-counter products", "Tell them they must see a doctor"] },
    { question: "When handling prescriptions, what is your top priority?", options: ["Speed and efficiency", "Accuracy in reading and entering data", "Verifying patient information", "Following all steps of the procedure exactly"] },
    { question: "How do you handle a situation where you are unsure about a task?", options: ["Guess the best course of action", "Wait until someone notices you need help", "Ask the pharmacist for clear instructions", "Look up the procedure in a manual"] },
    { question: "What quality is most important for a pharmacy technician?", options: ["Friendliness", "Reliability", "Speed", "Technical knowledge"] },
    { question: "You receive a new shipment of medicines. What is your first task?", options: ["Put them on the shelves immediately", "Verify the shipment against the purchase order", "Check for any damaged or expired products", "Organize them alphabetically"] },
    { question: "How do you feel about repetitive tasks like counting pills or labeling?", options: ["It's a calming and satisfying part of the job", "It can be boring, but it's necessary", "I try to find ways to do it faster each time", "I find it stressful because of the need for accuracy"] },
    { question: "The best part of working in a team is...", options: ["Having clear roles and responsibilities", "Learning from more experienced colleagues", "Social interaction with coworkers", "Achieving a shared goal efficiently"] },
    { question: "How do you see your career progressing after D.Pharm?", options: ["Continuing as a long-term pharmacy technician", "Pursuing further education like B.Pharm", "Moving into a pharmacy management or administrative role", "Exploring a different area of healthcare"] },
    { question: "When a pharmacist gives you feedback, your reaction is to...", options: ["Feel defensive", "Listen carefully and ask questions to improve", "Worry that you've made a serious mistake", "Nod along but continue doing it your way"] }
  ],
  "Medical Coding": [
    { question: "What is the most critical aspect of medical coding?", options: ["Speed of code entry", "Memorizing all the codes", "Accuracy and attention to detail", "Using the latest software"] },
    { question: "When you encounter a physician's note that is ambiguous or incomplete, what is your first step?", options: ["Make your best guess based on the available information", "Use a generic, unspecified code", "Query the physician for clarification", "Ask a fellow coder for their opinion"] },
    { question: "Which code set is used for reporting diagnoses?", options: ["CPT (Current Procedural Terminology)", "HCPCS Level II", "ICD-10-CM (International Classification of Diseases)", "NDC (National Drug Code)"] },
    { question: "How do you approach learning new coding guidelines or updates (like the yearly ICD-10 updates)?", options: ["I wait until I encounter a case that requires the new code", "I read the official updates from CMS and AMA thoroughly", "I rely on my coding software to handle the updates automatically", "I attend a summary webinar or workshop"] },
    { question: "You are coding a complex surgical procedure. What is your primary reference?", options: ["A quick Google search", "The physician's brief description", "The detailed operative report", "The hospital's billing department"] },
    { question: "What is your opinion on computer-assisted coding (CAC) software?", options: ["It's a threat to coders' jobs", "It's a valuable tool that improves efficiency but requires human oversight", "It's often inaccurate and unreliable", "It's the future and will eventually replace manual coding"] },
    { question: "Which quality is most important for a successful medical coder?", options: ["Strong anatomy and medical terminology knowledge", "Fast typing skills", "Good negotiation skills with insurers", "A background in accounting"] },
    { question: "A claim is denied due to a coding error. What is your reaction?", options: ["Assume the insurance company is wrong", "Blame the physician's poor documentation", "Methodically review the chart, codes, and denial reason to find the issue", "Immediately resubmit the claim with the same codes"] },
    { question: "What is the difference between upcoding and downcoding?", options: ["They are the same thing", "Upcoding is illegal; downcoding is just being cautious", "Upcoding is assigning a code for a higher-paying service; downcoding is assigning one for a lower-paying service", "Upcoding is for surgeries; downcoding is for office visits"] },
    { question: "What career path in health information management interests you the most?", options: ["Specializing in a complex area like oncology or cardiology coding", "Moving into a coding auditor or compliance officer role", "Becoming a clinical documentation improvement (CDI) specialist", "Managing a team of coders"] }
  ],
  "Nursing": [
    { question: "What are the 'Five Rights' of medication administration?", options: ["Right Patient, Right Drug, Right Dose, Right Route, Right Time", "Right Doctor, Right Nurse, Right Room, Right Bed, Right Chart", "Right Diagnosis, Right Treatment, Right Outcome, Right Cost, Right Follow-up", "Right Pharmacy, Right Manufacturer, Right Package, Right Color, Right Shape"] },
    { question: "When assessing a patient's pain, which method is considered the most reliable?", options: ["The nurse's observation of the patient's behavior", "The patient's self-report of pain", "The vital signs (heart rate, blood pressure)", "The type of injury or surgery"] },
    { question: "A patient's blood pressure is 150/95 mmHg. This is considered...", options: ["Hypotension (low blood pressure)", "Normal blood pressure", "Hypertension (high blood pressure)", "A medical emergency requiring immediate CPR"] },
    { question: "What is the primary purpose of using the SBAR technique (Situation, Background, Assessment, Recommendation)?", options: ["To document patient history", "For standardized and effective communication between healthcare professionals", "To calculate medication dosages", "To plan daily patient care"] },
    { question: "A patient develops a red, itchy rash after receiving a new antibiotic. This is likely a sign of...", options: ["A therapeutic effect", "An allergic reaction", "A common, expected side effect", "An infection at the IV site"] },
    { question: "Nosocomial infections are infections that are...", options: ["Acquired in a hospital or healthcare setting", "Resistant to all antibiotics", "Caused by viruses only", "Transmitted through the air"] },
    { question: "What is the normal range for an adult's respiratory rate?", options: ["5-10 breaths per minute", "12-20 breaths per minute", "25-30 breaths per minute", "30-40 breaths per minute"] },
    { question: "When providing patient education about a new diagnosis, the most important first step is to...", options: ["Give them several detailed pamphlets to read", "Assess their current level of understanding and readiness to learn", "Explain the worst-case scenarios to ensure they take it seriously", "Use complex medical terminology to be precise"] },
    { question: "A key principle of sterile technique is to...", options: ["Wash hands for at least 5 seconds", "Keep sterile objects above waist level", "Reuse sterile equipment to save costs", "Allow sterile fields to get wet"] },
    { question: "What is the primary ethical principle of 'non-maleficence' in nursing?", options: ["To do good", "To be fair", "To do no harm", "To respect patient autonomy"] }
  ],
  "Pharmacology": [
    { question: "Pharmacokinetics is the study of...", options: ["How a drug affects the body", "How the body absorbs, distributes, metabolizes, and excretes a drug", "The chemical structure of a drug", "The toxic effects of a drug"] },
    { question: "The 'first-pass effect' primarily occurs in which organ, significantly reducing the bioavailability of oral drugs?", options: ["Kidneys", "Lungs", "Liver", "Brain"] },
    { question: "A drug that binds to a receptor and activates it, producing a response, is called an...", options: ["Antagonist", "Agonist", "Inhibitor", "Inducer"] },
    { question: "Warfarin is an anticoagulant that works by inhibiting the synthesis of Vitamin K-dependent clotting factors. What is its main therapeutic use?", options: ["To treat bacterial infections", "To prevent blood clots", "To lower cholesterol", "To relieve pain"] },
    { question: "Which class of drugs is commonly used to treat hypertension by blocking the conversion of angiotensin I to angiotensin II?", options: ["Beta-blockers", "Calcium channel blockers", "Diuretics", "ACE inhibitors"] },
    { question: "What is a major, life-threatening side effect associated with opioid analgesics like morphine?", options: ["Nausea", "Constipation", "Respiratory depression", "Itching"] },
    { question: "'Half-life' (t½) of a drug refers to the time it takes for...", options: ["The drug to start working", "The drug to reach its peak effect", "The concentration of the drug in the body to be reduced by 50%", "The patient to feel better"] },
    { question: "What is the primary mechanism of action for penicillin antibiotics?", options: ["They inhibit protein synthesis in bacteria", "They inhibit bacterial cell wall synthesis", "They disrupt the bacterial cell membrane", "They inhibit bacterial DNA replication"] },
    { question: "A 'black box warning' on a drug's label indicates that...", options: ["The drug is not effective", "The drug may cause serious or life-threatening adverse effects", "The drug is a controlled substance", "The drug is for experimental use only"] },
    { question: "Which of the following drugs is a selective serotonin reuptake inhibitor (SSRI) commonly prescribed for depression?", options: ["Diazepam (Valium)", "Ibuprofen (Advil)", "Fluoxetine (Prozac)", "Atorvastatin (Lipitor)"] }
  ],
  "Senior Officer (Group A)": [
    { question: "What is the primary role of a top-level civil servant?", options: ["Strict enforcement of existing laws", "Effective implementation of government policies", "Formulation of new, innovative public policies", "Maintaining strong relationships with political leaders"] },
    { question: "You face a complex public issue with conflicting stakeholder interests. You prioritize...", options: ["The solution that benefits the most people", "The solution that aligns with long-term strategic goals", "A compromise that all parties can agree to", "The solution that is most legally and procedurally correct"] },
    { question: "How do you view public criticism of your department's work?", options: ["As a valuable source of feedback for improvement", "As an unavoidable part of public service", "As a political attack that must be defended against", "As a sign that communication needs to be improved"] },
    { question: "When making a critical decision, you rely most on...", options: ["Data analysis and expert reports", "Your own experience and intuition", "Precedent and established procedures", "Consultation with your team and superiors"] },
    { question: "What leadership style is most effective in a bureaucratic setting?", options: ["Authoritative and decisive", "Collaborative and consensus-building", "Transformational and inspiring", "Delegative and hands-off"] },
    { question: "A major infrastructure project is proposed for your district. Your biggest concern is...", options: ["Completing it on time and within budget", "Its long-term economic and social impact", "Ensuring transparency and preventing corruption", "Minimizing disruption to the public during construction"] },
    { question: "How should technology be used in governance?", options: ["To increase transparency and public access to information", "To improve the efficiency of internal processes", "To monitor and enforce compliance with laws", "To gather data for better policy-making"] },
    { question: "The biggest challenge in public service is...", options: ["Navigating political pressures", "Working with limited resources", "The slow pace of bureaucratic change", "Meeting the high expectations of the public"] },
    { question: "Your motivation for joining the civil service is primarily...", options: ["The opportunity to exercise authority and influence", "The desire to contribute to nation-building and public welfare", "The job security and social prestige", "The challenge of solving complex administrative problems"] },
    { question: "How do you balance following rules with the need for flexibility?", options: ["Rules are paramount and must be followed strictly", "Rules are guidelines; the spirit of the law is more important", "I would seek permission from a superior to bend the rules", "I would document any deviation from the rules and my justification"] }
  ],
  "Mid-level Officer (Group B)": [
    { question: "What is the most important aspect of an administrative role?", options: ["Meticulous record-keeping and documentation", "Efficient management of office workflow", "Clear communication with the public", "Effective supervision of subordinate staff"] },
    { question: "A new government scheme needs to be implemented. Your first step is to...", options: ["Understand the policy's objectives and target beneficiaries", "Create a detailed, step-by-step action plan", "Train the staff on the new procedures", "Launch a public awareness campaign"] },
    { question: "How do you handle a public grievance?", options: ["By following the standard procedure for complaints", "By listening empathetically and promising to investigate", "By providing a quick, practical solution if possible", "By explaining the rules and why their request cannot be met"] },
    { question: "What is the key to effective inter-departmental coordination?", options: ["Formal meetings and written communication", "Building good personal relationships", "Having clearly defined roles and responsibilities", "Escalating issues to higher authorities when needed"] },
    { question: "When managing a team, you focus on...", options: ["Ensuring everyone follows the rules", "Meeting performance targets and deadlines", "Maintaining high team morale", "The professional development of your staff"] },
    { question: "Your office needs to adopt a new software. Your main concern is...", options: ["The cost of the software", "How long it will take to train everyone", "The software's ability to improve efficiency", "The security of the data"] },
    { question: "What is your approach to paperwork?", options: ["A necessary part of ensuring accountability", "A tedious task that should be minimized", "An opportunity to understand the details of a case", "Something that can be delegated whenever possible"] },
    { question: "The most important quality for a mid-level officer is...", options: ["Decisiveness", "Integrity", "Adaptability", "Domain knowledge"] },
    { question: "How do you ensure fairness in your official duties?", options: ["By treating every case and person exactly the same", "By applying rules and regulations consistently", "By considering the unique circumstances of each case", "By being transparent about your decision-making process"] },
    { question: "You discover an inefficiency in a long-standing process. You...", options: ["Accept it as 'the way things are done'", "Suggest an improvement to your superior in a formal report", "Informally test a new, better way with your team", "Raise the issue in the next staff meeting"] }
  ],
  "Clerical Staff (Group C)": [
    { question: "What do you find most satisfying in a junior administrative role?", options: ["Completing a task accurately and on time", "Helping a citizen resolve their issue", "Keeping files and records perfectly organized", "Learning new office procedures"] },
    { question: "When given a complex task, you prefer...", options: ["A detailed, step-by-step list of instructions", "The freedom to figure out the best method yourself", "To collaborate with a colleague", "To break it down into smaller, manageable parts"] },
    { question: "The most important skill for this level is...", options: ["Typing speed and computer literacy", "Attention to detail", "Good communication skills", "Time management"] },
    { question: "How do you handle a heavy workload with tight deadlines?", options: ["Work longer hours to get everything done", "Prioritize tasks and focus on the most urgent ones first", "Ask a supervisor for help in prioritizing", "Stay calm and work steadily through the list"] },
    { question: "When dealing with the public, it's most important to be...", options: ["Polite and patient", "Efficient and quick", "Knowledgeable about the rules", "Strict and firm"] },
    { question: "You notice a small error in a document prepared by a senior. You...", options: ["Ignore it, as it's not your place to correct them", "Politely point it out to them in private", "Correct it yourself without telling them", "Ask another colleague what you should do"] },
    { question: "What part of office work do you enjoy the least?", options: ["Repetitive data entry", "Dealing with difficult people", "Searching for misplaced files", "Writing formal letters and notes"] },
    { question: "A good team member is someone who...", options: ["Always does their own work quietly", "Is willing to help others when they are finished", "Has a positive and cheerful attitude", "Follows the team leader's instructions without question"] },
    { question: "How do you feel about following a strict office hierarchy?", options: ["It provides clarity and is essential for discipline", "It can sometimes slow down work", "It is necessary, and I respect it", "I prefer a more informal work environment"] },
    { question: "When learning a new rule or procedure, you...", options: ["Need to have it explained to you several times", "Understand it quickly after reading it once", "Learn best by watching someone else do it", "Try to understand the reason behind the rule"] }
  ],
  "Support Staff (Group D)": [
    { question: "What is the most important part of your job?", options: ["Following instructions from my superiors precisely", "Completing my assigned tasks diligently every day", "Being punctual and presentable", "Maintaining the security and cleanliness of my workspace"] },
    { question: "When a member of the public approaches you for help, you...", options: ["Direct them to the correct person or counter", "Try to answer their question if you know the answer", "Listen patiently even if you can't help", "Politely tell them you are busy with your work"] },
    { question: "How do you feel about performing routine tasks every day?", options: ["I find comfort and stability in a predictable routine", "I get bored easily and need variety", "It's a job, and I do what is required", "I take pride in doing my routine tasks perfectly"] },
    { question: "The most important personal quality for this role is...", options: ["Honesty", "Punctuality", "Hard work", "Respectfulness"] },
    { question: "You are asked to carry a file from one office to another. You ensure...", options: ["You do it as fast as possible", "The file is delivered directly to the correct person", "You don't look at the contents of the file", "All of the above"] },
    { question: "If your supervisor is busy, and you have finished your work, you would...", options: ["Wait quietly until you are given another task", "Ask if there is anything else you can help with", "Tidy up your workspace and common areas", "Take a break"] },
    { question: "What makes you a reliable employee?", options: ["You are always on time", "You never miss a day of work without a valid reason", "You can be trusted to complete your tasks without supervision", "All of the above"] },
    { question: "How do you respond to being corrected by a superior?", options: ["I listen, apologize for the mistake, and learn from it", "I feel embarrassed and upset", "I try to explain why I did it that way", "It depends on how they correct me"] },
    { question: "Teamwork at this level means...", options: ["Not interfering with others' work", "Cooperating when asked to do a task together", "Being friendly with colleagues", "Covering for a colleague who is absent"] },
    { question: "Your main goal at work is to...", options: ["Earn a steady salary", "Do your duty to the best of your ability", "Learn new skills for a better future", "Avoid getting into any trouble"] }
  ],
};

const categories = {
  "Technical": ["CSE", "AI", "DS", "Cybersecurity", "Cloud Computing", "UI/UX Design", "ECE", "EEE", "CIVIL", "MECH"],
  "Medical": ["B.Pharm", "D.Pharm", "Pharmacology", "Nursing", "Medical Coding"],
  "Civil Services": ["Senior Officer (Group A)", "Mid-level Officer (Group B)", "Clerical Staff (Group C)", "Support Staff (Group D)"]
};

const loadingMessages = [
    "Analyzing your problem-solving approach...",
    "Mapping your learning style...",
    "Identifying your core strengths...",
    "Generating personalized skill-up plan...",
    "Finalizing your professional profile...",
];


const MindsetAnalyzer: React.FC<MindsetAnalyzerProps> = ({ isOpen, onClose }) => {
  const [quizState, setQuizState] = useState<QuizState>('branch_selection');
  const [selectedBranch, setSelectedBranch] = useState<keyof typeof quizData | null>(null);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [result, setResult] = useState<MindsetAnalysis | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState(loadingMessages[0]);
  const [error, setError] = useState<string | null>(null);

  // State for the new web search feature
  const [currentView, setCurrentView] = useState<ViewState>('quiz');
  const [isSearching, setIsSearching] = useState(false);
  const [searchPrompt, setSearchPrompt] = useState('');
  const [searchTargetBranch, setSearchTargetBranch] = useState<string | null>(null);
  const [searchResult, setSearchResult] = useState<{ text: string; sources: GroundingSource[] } | null>(null);
  const [searchError, setSearchError] = useState<string | null>(null);

  const handleBackToQuiz = () => {
    setCurrentView('quiz');
    setSearchPrompt('');
    setSearchTargetBranch(null);
    setSearchResult(null);
    setIsSearching(false);
    setSearchError(null);
  };

  const handleRestart = () => {
    setQuizState('branch_selection');
    setSelectedBranch(null);
    setAnswers({});
    setResult(null);
    setError(null);
    handleBackToQuiz(); // Also reset view to quiz
  }

  useEffect(() => {
    if (!isOpen) {
        // Delay reset to allow for closing animation
        setTimeout(() => {
            handleRestart();
        }, 300);
    }
  }, [isOpen]);

  const handleBranchSelect = (branch: keyof typeof quizData) => {
    setSelectedBranch(branch);
    setQuizState('taking');
    setAnswers({});
    setResult(null);
    setError(null);
  };

  const handleAnswerSelect = (qIndex: number, option: string) => {
    setAnswers(prev => ({ ...prev, [qIndex]: option }));
  };

  const handleSubmit = async () => {
    if (!selectedBranch || Object.keys(answers).length !== quizData[selectedBranch].length) {
      setError("Please answer all questions before submitting.");
      return;
    }
    
    let messageInterval: ReturnType<typeof setInterval> | null = null;

    try {
        setIsLoading(true);
        setError(null);
        setQuizState('analyzing');

        let messageIndex = 0;
        setLoadingMessage(loadingMessages[messageIndex]);
        messageInterval = setInterval(() => {
            messageIndex = (messageIndex + 1) % loadingMessages.length;
            setLoadingMessage(loadingMessages[messageIndex]);
        }, 2500);

        const formattedAnswers = quizData[selectedBranch].map((q, i) => `Question: ${q.question}\nAnswer: ${answers[i]}`).join('\n\n');
        const analysisResult = await analyzeMindset(formattedAnswers, selectedBranch);
        setResult(analysisResult);
        setQuizState('results');
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unknown error occurred.");
      setQuizState('taking');
    } finally {
      if (messageInterval) clearInterval(messageInterval);
      setIsLoading(false);
    }
  };

  const handlePerformSearch = async (promptToSearch: string) => {
    if (!promptToSearch.trim()) {
      setSearchError("Please enter a search query.");
      return;
    }
    setIsSearching(true);
    setSearchError(null);
    setSearchResult(null);

    try {
      const response = await groundedSearch(promptToSearch);
      setSearchResult(response);
    } catch (err) {
      setSearchError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    } finally {
      setIsSearching(false);
    }
  };

  const handleInitiateSearch = (branch: string) => {
    const defaultPrompt = `Top online learning platforms and resources for ${branch}`;
    setSearchTargetBranch(branch);
    setSearchPrompt(defaultPrompt);
    setCurrentView('search');
    handlePerformSearch(defaultPrompt);
  };

  const renderQuizContent = () => {
    switch (quizState) {
      case 'branch_selection':
         return (
          <div className="text-center">
            <h3 className="text-xl font-bold text-cyan-400">Discover Your Professional Mindset</h3>
            <p className="mt-2 text-gray-300">Select your field to start the quiz, or search for online learning resources.</p>
            <div className="mt-8 text-left space-y-6">
              {Object.entries(categories).map(([categoryName, branchesInCategory]) => (
                <div key={categoryName}>
                  <h4 className="text-base font-semibold text-cyan-400 uppercase tracking-wider mb-3">{categoryName}</h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    {branchesInCategory.map(branch => (
                       <div key={branch} className="bg-gray-700/50 rounded-lg flex flex-col justify-between shadow-lg">
                        <button
                            onClick={() => handleBranchSelect(branch as keyof typeof quizData)}
                            className="flex-grow p-4 text-center w-full hover:bg-cyan-500/10 rounded-t-lg transition-colors duration-200"
                            aria-label={`Start mindset quiz for ${branch}`}
                        >
                            <span className="font-semibold text-white">{branch}</span>
                        </button>
                        <div className="border-t border-gray-600/50">
                            <button
                                onClick={() => handleInitiateSearch(branch)}
                                className="text-xs w-full text-cyan-400 hover:bg-cyan-500/20 p-2 rounded-b-lg transition-colors duration-200 flex items-center justify-center space-x-1.5"
                                aria-label={`Search online learning platforms for ${branch}`}
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                    <path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
                                </svg>
                                <span>Learn Online</span>
                            </button>
                        </div>
                    </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      case 'taking':
        if (!selectedBranch) return null;
        const currentQuestions = quizData[selectedBranch];
        return (
          <div>
            <h3 className="text-xl font-bold text-cyan-400 mb-6 text-center">{selectedBranch} Mindset Quiz</h3>
            <div className="space-y-6">
                {currentQuestions.map((q, qIndex) => (
                <div key={qIndex} className="bg-gray-700/50 p-4 rounded-lg">
                    <p className="font-semibold text-white mb-3">{qIndex + 1}. {q.question}</p>
                    <div className="space-y-2">
                    {q.options.map((option, oIndex) => (
                        <label key={oIndex} className={`flex items-start space-x-3 p-3 rounded-md transition-colors cursor-pointer ${answers[qIndex] === option ? 'bg-cyan-500/30 ring-2 ring-cyan-500' : 'hover:bg-gray-600'}`}>
                        <input type="radio" name={`question-${qIndex}`} value={option} checked={answers[qIndex] === option} onChange={() => handleAnswerSelect(qIndex, option)} className="form-radio h-4 w-4 text-cyan-500 bg-gray-800 border-gray-600 focus:ring-cyan-600 mt-1 flex-shrink-0" />
                        <span className="text-gray-300 text-sm">{option}</span>
                        </label>
                    ))}
                    </div>
                </div>
                ))}
            </div>
            {error && <p className="text-center text-red-400 bg-red-900/50 p-3 rounded-lg mt-4">{error}</p>}
            <button onClick={handleSubmit} disabled={Object.keys(answers).length !== currentQuestions.length} className="w-full mt-6 bg-green-600 text-white py-2 rounded-md hover:bg-green-700 disabled:bg-gray-500 disabled:cursor-not-allowed">
                Analyze My Mindset
            </button>
          </div>
        );
      case 'analyzing':
        return (
            <div className="text-center p-4">
                <p className="text-cyan-400 font-semibold mb-2">Analyzing Your Results...</p>
                <p className="text-sm text-gray-300 h-4">{loadingMessage}</p>
                <div className="mt-4 flex justify-center"><Loader /></div>
            </div>
        );
       case 'results':
        return result && (
            <div>
                 <div className="text-center mb-6 p-4 bg-gray-900/50 rounded-lg border border-cyan-500/50">
                    <p className="text-sm font-semibold text-cyan-400 uppercase tracking-widest">{selectedBranch} FIELD</p>
                    <h3 className="text-2xl font-bold text-white mt-1">{result.mindsetProfile.title}</h3>
                    <p className="text-gray-300 mt-2">{result.mindsetProfile.description}</p>
                </div>
                <div className="bg-gray-700/50 p-4 rounded-lg">
                     <h4 className="text-lg font-bold text-white mb-3">Your Personalized Skill-Up Plan</h4>
                     <div className="space-y-4">
                        <div>
                            <h5 className="font-semibold text-cyan-400">Focus Areas:</h5>
                            <ul className="list-disc list-inside text-sm text-gray-300 mt-1 space-y-1">
                                {result.skillUpPlan.focusAreas.map(area => <li key={area}>{area}</li>)}
                            </ul>
                        </div>
                         <div>
                            <h5 className="font-semibold text-cyan-400">Recommended Resources:</h5>
                             <ul className="list-disc list-inside text-sm text-gray-300 mt-1 space-y-1">
                                {result.skillUpPlan.recommendedResources.map(res => <li key={res}>{res}</li>)}
                            </ul>
                        </div>
                         <div>
                            <h5 className="font-semibold text-cyan-400">Suggested Next Project:</h5>
                            <p className="text-sm text-gray-300 mt-1">{result.skillUpPlan.nextProject}</p>
                        </div>
                     </div>
                </div>
                <button onClick={handleRestart} className="w-full mt-6 bg-cyan-500 text-white py-2 rounded-md hover:bg-cyan-600">
                    Change Field or Retake
                </button>
            </div>
        );
      default:
        return null;
    }
  };
  
  const renderWebSearch = () => (
    <div>
        <button onClick={handleBackToQuiz} className="flex items-center space-x-2 text-sm text-cyan-400 hover:text-cyan-300 mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
            <span>Back to Field Selection</span>
        </button>
        <h3 className="text-xl font-bold text-white mb-1">Learn Online</h3>
        <p className="text-gray-400 text-sm mb-4">Showing resources for: <span className="font-semibold text-gray-200">{searchTargetBranch}</span></p>

        <form onSubmit={(e) => { e.preventDefault(); handlePerformSearch(searchPrompt); }} className="flex items-center space-x-2">
            <input
                type="text"
                value={searchPrompt}
                onChange={(e) => setSearchPrompt(e.target.value)}
                placeholder="Search for resources..."
                className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                disabled={isSearching}
            />
            <button
                type="submit"
                disabled={isSearching || !searchPrompt.trim()}
                className="bg-cyan-500 text-white rounded-md px-4 py-2 hover:bg-cyan-600 disabled:bg-gray-600"
            >
                {isSearching ? <Loader /> : 'Search'}
            </button>
        </form>

        <div className="mt-6 space-y-4">
            {isSearching && <div className="flex justify-center pt-10"><Loader /></div>}
            {searchError && <p className="text-center text-red-400 bg-red-900/50 p-3 rounded-lg">{searchError}</p>}
            
            {searchResult && (
                <div>
                    <div className="p-4 bg-gray-900/50 rounded-lg mb-4">
                        <h3 className="font-bold text-lg mb-2 text-cyan-400">Answer</h3>
                        <p className="whitespace-pre-wrap text-gray-200 text-sm">{searchResult.text}</p>
                    </div>

                    {searchResult.sources.length > 0 && (
                        <div>
                            <h4 className="font-bold text-md mb-2 text-cyan-400">Sources</h4>
                            <ul className="space-y-2">
                                {searchResult.sources.map((source, index) => (
                                    <li key={index} className="text-sm bg-gray-700/50 p-3 rounded-md">
                                        <a href={source.uri} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline break-all" title={source.uri}>
                                            {source.title || source.uri}
                                        </a>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    )}
                </div>
            )}
        </div>
    </div>
);

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="AI Mindset Analyzer">
      <div className="p-6">
        {currentView === 'quiz' ? renderQuizContent() : renderWebSearch()}
      </div>
    </Modal>
  );
};

export default MindsetAnalyzer;
