import React, { useState, useRef, useCallback } from 'react';
import Modal from './Modal';
import Loader from './Loader';
import { generateVideo, pollVideoOperation } from '../services/geminiService';

interface AnimateImageGeneratorProps {
  isOpen: boolean;
  onClose: () => void;
}

const loadingMessages = [
    "Warming up the animation engine...",
    "Analyzing image and motion prompt...",
    "Rendering initial frames, this may take a moment...",
    "The AI is bringing your image to life...",
    "Applying motion vectors and visual effects...",
    "Almost there, finalizing the animation...",
];

const fileToBase64 = (file: File): Promise<{ data: string; mimeType: string }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      const base64Data = result.split(',')[1];
      resolve({ data: base64Data, mimeType: file.type });
    };
    reader.onerror = (error) => reject(error);
  });
};

const AnimateImageGenerator: React.FC<AnimateImageGeneratorProps> = ({ isOpen, onClose }) => {
  const [prompt, setPrompt] = useState('');
  const [imageFile, setImageFile] = useState<{ file: File, preview: string } | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState(loadingMessages[0]);
  const [error, setError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [motionIntensity, setMotionIntensity] = useState<'Subtle' | 'Normal' | 'High'>('Normal');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const pollingIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const cleanup = () => {
    if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
        pollingIntervalRef.current = null;
    }
  };
  
  const pollForVideo = async (operation: any) => {
    let messageIndex = 0;
    setLoadingMessage(loadingMessages[messageIndex]);
    const messageInterval = setInterval(() => {
        messageIndex = (messageIndex + 1) % loadingMessages.length;
        setLoadingMessage(loadingMessages[messageIndex]);
    }, 10000); // Change message every 10 seconds

    while (true) {
        try {
            await new Promise(resolve => setTimeout(resolve, 5000)); // Poll every 5 seconds
            const updatedOperation = await pollVideoOperation(operation);
            operation = updatedOperation;

            if (updatedOperation.done) {
                const downloadLink = updatedOperation.response?.generatedVideos?.[0]?.video?.uri;
                if (downloadLink) {
                    const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
                    const blob = await response.blob();
                    const url = URL.createObjectURL(blob);
                    setVideoUrl(url);
                } else {
                   throw new Error("Animation completed, but no video URL was found.");
                }
                break; // Exit loop
            }
        } catch (err) {
            setError(err instanceof Error ? err.message : "An error occurred during polling.");
            break; // Exit loop on error
        }
    }
    clearInterval(messageInterval);
    setIsLoading(false);
  };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!imageFile) {
        setError("Please upload an image to animate.");
        return;
    }
    if (!prompt.trim()) {
        setError("Please describe how you want to animate the image.");
        return;
    }
    
    cleanup();
    setIsLoading(true);
    setError(null);
    setVideoUrl(null);

    try {
        const imagePayload = await fileToBase64(imageFile.file);

        let intensityPrefix = '';
        switch (motionIntensity) {
            case 'Subtle':
                intensityPrefix = 'Animate with subtle, gentle motion. ';
                break;
            case 'High':
                intensityPrefix = 'Animate with high energy and intensity. ';
                break;
            case 'Normal':
            default:
                intensityPrefix = '';
                break;
        }
        const fullPrompt = `${intensityPrefix}${prompt}`;
        
        const initialOperation = await generateVideo(fullPrompt, imagePayload);
        await pollForVideo(initialOperation);

    } catch (err) {
      setError(err instanceof Error ? err.message : "An unknown error occurred.");
      setIsLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const preview = URL.createObjectURL(file);
      setImageFile({ file, preview });
      setError(null);
    }
  };

  const removeImage = () => {
    if (imageFile) {
        URL.revokeObjectURL(imageFile.preview);
        setImageFile(null);
    }
  }

  // Drag and drop handlers
  const handleDragEnter = useCallback((e: React.DragEvent) => { e.preventDefault(); e.stopPropagation(); setIsDragging(true); }, []);
  const handleDragLeave = useCallback((e: React.DragEvent) => { e.preventDefault(); e.stopPropagation(); setIsDragging(false); }, []);
  const handleDragOver = useCallback((e: React.DragEvent) => { e.preventDefault(); e.stopPropagation(); }, []);
  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const preview = URL.createObjectURL(file);
      setImageFile({ file, preview });
      setError(null);
    }
  }, []);

  return (
    <Modal isOpen={isOpen} onClose={() => { onClose(); cleanup(); }} title="AI Image Animator">
      <div className="p-6">
        <p className="text-sm text-gray-400 mb-4">
          Bring your images to life! Upload an image and describe the animation you envision. This process can take several minutes.
        </p>
        <form onSubmit={handleSubmit}>
            {imageFile ? (
                 <div className="mb-4 relative w-fit mx-auto">
                    <img src={imageFile.preview} alt="upload preview" className="max-h-48 object-contain rounded-md" />
                     <button type="button" onClick={removeImage} className="absolute -top-2 -right-2 bg-gray-700 text-white rounded-full h-6 w-6 flex items-center justify-center text-xs hover:bg-gray-600">✕</button>
                </div>
            ) : (
                <div 
                    onDragEnter={handleDragEnter} 
                    onDragLeave={handleDragLeave} 
                    onDragOver={handleDragOver} 
                    onDrop={handleDrop} 
                    onClick={() => fileInputRef.current?.click()}
                    className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors mb-4 ${isDragging ? 'border-cyan-400 bg-gray-700/50' : 'border-gray-600 hover:border-cyan-500 text-gray-400'}`}
                >
                    <input type="file" accept="image/*" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
                    <div className="flex flex-col items-center justify-center space-y-2">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
                        <p className="font-semibold text-gray-200">Drag & drop an image here</p>
                        <p className="text-xs">or click to select a file</p>
                    </div>
                </div>
            )}
          <div className="mb-4">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe the animation... e.g., Make the waterfall flow and add mist"
              rows={3}
              className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-500"
              disabled={isLoading}
            />
          </div>
          
          <div className="mb-6">
             <label className="text-sm text-gray-400 block mb-2 font-semibold">Motion Intensity</label>
             <div className="flex flex-wrap gap-2">
                {(['Subtle', 'Normal', 'High'] as const).map(level => (
                    <button
                        key={level}
                        type="button"
                        onClick={() => setMotionIntensity(level)}
                        className={`px-3 py-1 text-sm rounded-full transition-colors ${motionIntensity === level ? 'bg-cyan-500 text-white font-semibold' : 'bg-gray-600 hover:bg-gray-500'}`}
                    >
                        {level}
                    </button>
                ))}
             </div>
          </div>

          <button
            type="submit"
            disabled={isLoading || !prompt.trim() || !imageFile}
            className="w-full bg-cyan-500 text-white rounded-md px-4 py-2.5 hover:bg-cyan-600 focus:outline-none disabled:bg-gray-600 flex justify-center items-center"
          >
            {isLoading ? <Loader /> : 'Animate'}
          </button>
        </form>

        {error && <p className="text-center text-red-400 bg-red-900/50 p-3 rounded-lg mt-4">{error}</p>}
        
        <div className="mt-6">
          {isLoading && (
            <div className="text-center p-4 bg-gray-700/50 rounded-lg">
                <p className="text-cyan-400 font-semibold mb-2">Animating Your Image...</p>
                <p className="text-sm text-gray-300">{loadingMessage}</p>
                <div className="mt-4 flex justify-center"><Loader /></div>
            </div>
          )}
          {videoUrl && (
            <div>
              <video controls autoPlay loop src={videoUrl} className="w-full rounded-lg" />
              <a
                href={videoUrl}
                download={`animated_image_${prompt.slice(0, 20).replace(/\s/g, '_')}.mp4`}
                className="block w-full mt-4 text-center text-sm bg-gray-700 text-cyan-300 border border-gray-600 px-4 py-2 rounded-md hover:bg-gray-600"
              >
                Download Animation
              </a>
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
};

export default AnimateImageGenerator;