
import React from 'react';

interface WelcomeScreenProps {
  sendMessage: (message: string, isWebSearchEnabled: boolean) => void;
}

const examplePrompts = [
  "Explain quantum computing in simple terms",
  "Write a python script to sort a list of strings",
  "What are the main differences between React and Vue?",
  "Create a recipe for a vegan chocolate cake",
];

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ sendMessage }) => {
  return (
    <div className="flex-grow flex flex-col items-center justify-center text-center p-8">
      <h1 className="text-4xl md:text-5xl font-bold mb-4 text-white">
        Welcome To Prism AI World 👋
      </h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8 max-w-4xl w-full">
        {examplePrompts.map((prompt) => (
          <button
            key={prompt}
            onClick={() => sendMessage(prompt, false)}
            className="p-4 bg-white/5 backdrop-blur-md border border-white/10 rounded-lg text-left hover:bg-white/10 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-cyan-400"
          >
            <p className="font-semibold text-gray-200">{prompt}</p>
          </button>
        ))}
      </div>
    </div>
  );
};