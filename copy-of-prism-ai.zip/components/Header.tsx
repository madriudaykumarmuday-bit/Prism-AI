import React, { useState, useEffect, useRef } from 'react';
import { Icon } from './Icon';
import { Language } from '../types';
import VideoGenerator from './VideoGenerator';
import AssessmentCreator from './AssessmentCreator';
import CodeRunner from './CodeRunner';
import ImageGenerator from './ImageGenerator';
import LearningHub from './LearningHub';
import LogoCreator from './LogoCreator';
import MindsetAnalyzer from './MindsetAnalyzer';
import PresentationGenerator from './PresentationGenerator';
import ProjectIdeaGenerator from './ProjectIdeaGenerator';
import ResumeBuilder from './ResumeBuilder';
import StudentSuccessHub from './StudentSuccessHub';
import WebSearchPanel from './WebSearchPanel';
import CourseCreator from './CourseCreator';
import InterviewPrepHub from './InterviewPrepHub';
import Clock from './Clock';
import Calendar from './Calendar';
import AnimateImageGenerator from './AnimateImageGenerator';
import StoryWeaver from './StoryWeaver';
import ImageEditor from './ImageEditor';

interface AITool {
  name: string;
  icon: 'book-open' | 'academic-cap' | 'chart-pie' | 'code-bracket' | 'photo' | 'film' | 'swatch' | 'presentation-chart-bar' | 'light-bulb' | 'identification' | 'school' | 'search' | 'collection' | 'puzzle-piece' | 'calendar' | 'play' | 'beaker' | 'wand';
}

const aiTools: AITool[] = [
    // Productivity & Planning
    { name: 'Calendar', icon: 'calendar' },
    { name: 'Web Search', icon: 'search' },
    { name: 'Project Idea Generator', icon: 'light-bulb'},
    { name: 'Presentation Generator', icon: 'presentation-chart-bar' },
    
    // Learning & Career
    { name: 'Course Creator', icon: 'collection' },
    { name: 'Learning Hub', icon: 'book-open' },
    { name: 'Student Success Hub', icon: 'school' },
    { name: 'Interview Prep Hub', icon: 'puzzle-piece' },
    { name: 'Resume Builder', icon: 'identification' },
    { name: 'Mindset Analyzer', icon: 'chart-pie' },
    { name: 'Create Assessment', icon: 'academic-cap' },

    // Creative & Content
    { name: 'AI Story Weaver', icon: 'beaker' },
    { name: 'Image Editor', icon: 'wand' },
    { name: 'Generate Image', icon: 'photo' },
    { name: 'Animate Image', icon: 'play' },
    { name: 'Video Generator', icon: 'film' },
    { name: 'Logo Creator', icon: 'swatch' },

    // Development
    { name: 'Code Runner', icon: 'code-bracket' },
];

interface HeaderProps {
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
  learningContext: string;
}

export const Header: React.FC<HeaderProps> = ({ currentLanguage, onLanguageChange, learningContext }) => {
  const [isToolkitOpen, setIsToolkitOpen] = useState(false);
  const [isLangOpen, setIsLangOpen] = useState(false);
  
  // Modal states for each tool
  const [isVideoGeneratorOpen, setIsVideoGeneratorOpen] = useState(false);
  const [isAssessmentOpen, setIsAssessmentOpen] = useState(false);
  const [isCodeRunnerOpen, setIsCodeRunnerOpen] = useState(false);
  const [isImageGeneratorOpen, setIsImageGeneratorOpen] = useState(false);
  const [isLearningHubOpen, setIsLearningHubOpen] = useState(false);
  const [isLogoCreatorOpen, setIsLogoCreatorOpen] = useState(false);
  const [isMindsetAnalyzerOpen, setIsMindsetAnalyzerOpen] = useState(false);
  const [isPresentationGeneratorOpen, setIsPresentationGeneratorOpen] = useState(false);
  const [isProjectIdeaGeneratorOpen, setIsProjectIdeaGeneratorOpen] = useState(false);
  const [isResumeBuilderOpen, setIsResumeBuilderOpen] = useState(false);
  const [isStudentSuccessHubOpen, setIsStudentSuccessHubOpen] = useState(false);
  const [isWebSearchPanelOpen, setIsWebSearchPanelOpen] = useState(false);
  const [isCourseCreatorOpen, setIsCourseCreatorOpen] = useState(false);
  const [isInterviewPrepOpen, setIsInterviewPrepOpen] = useState(false);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [isAnimateImageGeneratorOpen, setIsAnimateImageGeneratorOpen] = useState(false);
  const [isStoryWeaverOpen, setIsStoryWeaverOpen] = useState(false);
  const [isImageEditorOpen, setIsImageEditorOpen] = useState(false);

  const [modalContext, setModalContext] = useState('');

  
  const toolkitRef = useRef<HTMLDivElement>(null);
  const langRef = useRef<HTMLDivElement>(null);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (toolkitRef.current && !toolkitRef.current.contains(event.target as Node)) {
        setIsToolkitOpen(false);
      }
      if (langRef.current && !langRef.current.contains(event.target as Node)) {
        setIsLangOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleToolClick = (toolName: string) => {
    // This could be refactored into a map for cleanliness
    if (toolName === 'Video Generator') setIsVideoGeneratorOpen(true);
    else if (toolName === 'Animate Image') setIsAnimateImageGeneratorOpen(true);
    else if (toolName === 'Create Assessment') {
        setModalContext(''); // Use context from chat
        setIsAssessmentOpen(true);
    } 
    else if (toolName === 'Code Runner') setIsCodeRunnerOpen(true);
    else if (toolName === 'Generate Image') setIsImageGeneratorOpen(true);
    else if (toolName === 'Image Editor') setIsImageEditorOpen(true);
    else if (toolName === 'Learning Hub') setIsLearningHubOpen(true);
    else if (toolName === 'Logo Creator') setIsLogoCreatorOpen(true);
    else if (toolName === 'Mindset Analyzer') setIsMindsetAnalyzerOpen(true);
    else if (toolName === 'Presentation Generator') setIsPresentationGeneratorOpen(true);
    else if (toolName === 'Project Idea Generator') setIsProjectIdeaGeneratorOpen(true);
    else if (toolName === 'Resume Builder') setIsResumeBuilderOpen(true);
    else if (toolName === 'Student Success Hub') setIsStudentSuccessHubOpen(true);
    else if (toolName === 'Web Search') setIsWebSearchPanelOpen(true);
    else if (toolName === 'Course Creator') setIsCourseCreatorOpen(true);
    else if (toolName === 'Interview Prep Hub') setIsInterviewPrepOpen(true);
    else if (toolName === 'Calendar') setIsCalendarOpen(true);
    else if (toolName === 'AI Story Weaver') setIsStoryWeaverOpen(true);
    
    setIsToolkitOpen(false);
  };

  const handleCreateAssessmentFromHub = (context: string) => {
    setModalContext(context);
    setIsLearningHubOpen(false);
    setIsAssessmentOpen(true);
  };

  const handleLangChange = (lang: Language) => {
    onLanguageChange(lang);
    setIsLangOpen(false);
  };

  return (
    <>
      <header className="flex items-center justify-between p-4 border-b border-white/10 bg-black/20 backdrop-blur-lg flex-shrink-0">
        <div className="flex items-center gap-3">
          <Icon as="prism" className="w-8 h-8 text-cyan-400" />
          <h1 className="text-xl font-semibold text-gray-200">Prism AI</h1>
        </div>

        <div className="flex items-center gap-4">
          <Clock />
          {/* AI Tool Kit */}
          <div className="relative" ref={toolkitRef}>
            <button
              onClick={() => setIsToolkitOpen(prev => !prev)}
              className="p-2 rounded-full text-gray-300 hover:text-white hover:bg-white/10 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-cyan-500"
              aria-haspopup="true"
              aria-expanded={isToolkitOpen}
              aria-label="Open AI Tool Kit"
            >
              <Icon as="briefcase" className="w-6 h-6" />
            </button>

            {isToolkitOpen && (
              <div className="absolute right-0 mt-2 w-56 origin-top-right bg-gray-900/80 backdrop-blur-lg border border-white/10 rounded-md shadow-lg ring-1 ring-black ring-opacity-5 z-10">
                <div className="py-1 max-h-[70vh] overflow-y-auto" role="menu" aria-orientation="vertical" aria-labelledby="options-menu">
                  {aiTools.map((tool) => (
                    <button
                      key={tool.name}
                      onClick={() => handleToolClick(tool.name)}
                      className="flex items-center gap-3 w-full text-left px-4 py-2 text-sm text-gray-300 hover:bg-white/10 hover:text-white"
                      role="menuitem"
                    >
                      <Icon as={tool.icon} className="w-5 h-5" />
                      <span>{tool.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Language Selector */}
          <div className="relative" ref={langRef}>
              <button
                onClick={() => setIsLangOpen(prev => !prev)}
                className="p-2 rounded-full text-gray-300 hover:text-white hover:bg-white/10 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-cyan-500"
                aria-haspopup="true"
                aria-expanded={isLangOpen}
                aria-label="Select language"
              >
                <Icon as="globe" className="w-6 h-6" />
              </button>
              {isLangOpen && (
                  <div className="absolute right-0 mt-2 w-40 origin-top-right bg-gray-900/80 backdrop-blur-lg border border-white/10 rounded-md shadow-lg ring-1 ring-black ring-opacity-5 z-10">
                      <div className="py-1" role="menu" aria-orientation="vertical">
                          {(['English', 'Telugu'] as Language[]).map((lang) => (
                              <button
                                key={lang}
                                onClick={() => handleLangChange(lang)}
                                className="flex items-center justify-between w-full text-left px-4 py-2 text-sm text-gray-300 hover:bg-white/10 hover:text-white"
                                role="menuitem"
                              >
                                <span>{lang}</span>
                                {currentLanguage === lang && <Icon as="check" className="w-5 h-5 text-cyan-400" />}
                              </button>
                          ))}
                      </div>
                  </div>
              )}
          </div>
        </div>
      </header>
      
      {/* Tool Modals */}
      <VideoGenerator isOpen={isVideoGeneratorOpen} onClose={() => setIsVideoGeneratorOpen(false)} />
      <AnimateImageGenerator isOpen={isAnimateImageGeneratorOpen} onClose={() => setIsAnimateImageGeneratorOpen(false)} />
      <AssessmentCreator 
        isOpen={isAssessmentOpen} 
        onClose={() => setIsAssessmentOpen(false)}
        learningContext={modalContext || learningContext}
      />
      <CodeRunner isOpen={isCodeRunnerOpen} onClose={() => setIsCodeRunnerOpen(false)} />
      <ImageGenerator isOpen={isImageGeneratorOpen} onClose={() => setIsImageGeneratorOpen(false)} />
      <ImageEditor isOpen={isImageEditorOpen} onClose={() => setIsImageEditorOpen(false)} />
      <LearningHub 
        isOpen={isLearningHubOpen}
        onClose={() => setIsLearningHubOpen(false)}
        onCreateAssessment={handleCreateAssessmentFromHub}
      />
      <LogoCreator isOpen={isLogoCreatorOpen} onClose={() => setIsLogoCreatorOpen(false)} />
      <MindsetAnalyzer isOpen={isMindsetAnalyzerOpen} onClose={() => setIsMindsetAnalyzerOpen(false)} />
      <PresentationGenerator isOpen={isPresentationGeneratorOpen} onClose={() => setIsPresentationGeneratorOpen(false)} />
      <ProjectIdeaGenerator isOpen={isProjectIdeaGeneratorOpen} onClose={() => setIsProjectIdeaGeneratorOpen(false)} />
      <ResumeBuilder isOpen={isResumeBuilderOpen} onClose={() => setIsResumeBuilderOpen(false)} />
      <StudentSuccessHub isOpen={isStudentSuccessHubOpen} onClose={() => setIsStudentSuccessHubOpen(false)} />
      <WebSearchPanel isOpen={isWebSearchPanelOpen} onClose={() => setIsWebSearchPanelOpen(false)} />
      <CourseCreator isOpen={isCourseCreatorOpen} onClose={() => setIsCourseCreatorOpen(false)} />
      <InterviewPrepHub isOpen={isInterviewPrepOpen} onClose={() => setIsInterviewPrepOpen(false)} />
      <Calendar isOpen={isCalendarOpen} onClose={() => setIsCalendarOpen(false)} />
      <StoryWeaver isOpen={isStoryWeaverOpen} onClose={() => setIsStoryWeaverOpen(false)} />
    </>
  );
};