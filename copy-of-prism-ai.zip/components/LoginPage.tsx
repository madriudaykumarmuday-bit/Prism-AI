import React, { useState } from 'react';
import { Icon } from './Icon';

interface LoginPageProps {
  onLogin: () => void;
}

interface AITool {
  name: string;
  icon: 'book-open' | 'academic-cap' | 'chart-pie' | 'code-bracket' | 'photo' | 'film' | 'swatch' | 'presentation-chart-bar' | 'light-bulb' | 'identification' | 'school' | 'search' | 'collection';
}

const aiTools: AITool[] = [
    { name: 'Course Creator', icon: 'collection' },
    { name: 'Web Search', icon: 'search' },
    { name: 'Learning Hub', icon: 'book-open' },
    { name: 'Student Success Hub', icon: 'school' },
    { name: 'Create Assessment', icon: 'academic-cap' },
    { name: 'Mindset Analyzer', icon: 'chart-pie' },
    { name: 'Project Idea Generator', icon: 'light-bulb'},
    { name: 'Presentation Generator', icon: 'presentation-chart-bar' },
    { name: 'Resume Builder', icon: 'identification' },
    { name: 'Code Runner', icon: 'code-bracket' },
    { name: 'Generate Image', icon: 'photo' },
    { name: 'Video Generator', icon: 'film' },
    { name: 'Logo Creator', icon: 'swatch' },
];

interface UpcomingAITool {
  name: string;
  icon: 'music-note' | 'map' | 'chat-bubble-left-right' | 'moon';
}

const upcomingTools: UpcomingAITool[] = [
    { name: 'Music Composer', icon: 'music-note' },
    { name: 'Trip Planner', icon: 'map' },
    { name: 'Debate Coach', icon: 'chat-bubble-left-right' },
    { name: 'Dream Interpreter', icon: 'moon' },
];

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [mode, setMode] = useState<'login' | 'signup'>('login');

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center p-4 sm:p-6">
      <div className="w-full max-w-6xl mx-auto">
        <div className="text-center">
          <Icon as="prism" className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
          <h1 className="text-4xl sm:text-5xl font-bold text-gray-100">Welcome to Prism AI</h1>
          <p className="mt-2 text-lg text-gray-300">Your all-in-one AI-powered toolkit.</p>
        </div>

        <div className="mt-10 max-w-sm mx-auto bg-black/20 p-8 rounded-2xl border border-white/10 backdrop-blur-lg">
            <div className="space-y-4">
                <button
                    onClick={onLogin}
                    className="w-full flex items-center justify-center gap-3 bg-white text-gray-800 font-semibold py-2.5 rounded-md hover:bg-gray-200 transition-colors"
                >
                    <Icon as="google" className="w-5 h-5" />
                    Sign in with Google
                </button>
            </div>
            <div className="flex items-center my-4">
                <div className="flex-grow border-t border-gray-700"></div>
                <span className="flex-shrink mx-4 text-gray-500 text-sm">or</span>
                <div className="flex-grow border-t border-gray-700"></div>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); onLogin(); }}>
                <div className="space-y-4">
                    <div>
                        <label htmlFor="email" className="text-sm font-medium text-gray-400">Email</label>
                        <input type="email" id="email" className="w-full mt-1 bg-black/20 border border-white/10 rounded-md py-2 px-4 focus:outline-none focus:ring-2 focus:ring-cyan-500" placeholder="you@example.com" />
                    </div>
                    <div>
                        <label htmlFor="password" className="text-sm font-medium text-gray-400">Password</label>
                        <input type="password" id="password" className="w-full mt-1 bg-black/20 border border-white/10 rounded-md py-2 px-4 focus:outline-none focus:ring-2 focus:ring-cyan-500" placeholder="••••••••" />
                    </div>
                    {mode === 'signup' && (
                        <div>
                            <label htmlFor="confirm_password" className="text-sm font-medium text-gray-400">Confirm Password</label>
                            <input type="password" id="confirm_password" className="w-full mt-1 bg-black/20 border border-white/10 rounded-md py-2 px-4 focus:outline-none focus:ring-2 focus:ring-cyan-500" placeholder="••••••••" />
                        </div>
                    )}
                </div>
                <button type="submit" className="w-full mt-6 bg-cyan-500 text-white font-semibold py-2.5 rounded-md hover:bg-cyan-600 transition-colors">
                    {mode === 'login' ? 'Login' : 'Create Account'}
                </button>
            </form>
            <div className="text-center mt-4 text-sm">
                 {mode === 'login' ? (
                    <p className="text-gray-400">
                        Don't have an account?{' '}
                        <button onClick={() => setMode('signup')} className="font-semibold text-cyan-400 hover:text-cyan-300 transition-colors">
                            Create one
                        </button>
                    </p>
                 ) : (
                    <p className="text-gray-400">
                        Already have an account?{' '}
                        <button onClick={() => setMode('login')} className="font-semibold text-cyan-400 hover:text-cyan-300 transition-colors">
                            Login
                        </button>
                    </p>
                 )}
            </div>
            <div className="text-center mt-6">
                <button onClick={onLogin} className="text-sm text-gray-400 hover:text-gray-200 transition-colors">
                    Continue as Guest
                </button>
            </div>
        </div>
        
        <div className="mt-16 text-center">
            <h2 className="text-2xl font-bold text-gray-200">Explore the AI Tool Kit</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 mt-6">
                {aiTools.map(tool => (
                    <div key={tool.name} className="bg-black/20 backdrop-blur-md p-4 rounded-lg border border-white/10 flex flex-col items-center justify-center space-y-2 hover:bg-white/10 transition-colors">
                        <Icon as={tool.icon} className="w-8 h-8 text-cyan-400" />
                        <span className="text-sm font-medium text-gray-300 text-center">{tool.name}</span>
                    </div>
                ))}
            </div>
        </div>
        
        <div className="mt-16 text-center pb-8">
            <h2 className="text-2xl font-bold text-gray-200">Upcoming AI Tools</h2>
            <p className="mt-2 text-sm text-gray-500">Get a glimpse of what's next for Prism AI.</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6">
                {upcomingTools.map(tool => (
                    <div key={tool.name} className="relative bg-black/20 backdrop-blur-md p-4 rounded-lg border border-white/10 flex flex-col items-center justify-center space-y-2 opacity-60 cursor-not-allowed">
                        <span className="absolute top-1.5 right-1.5 bg-yellow-400 text-yellow-900 text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                            SOON
                        </span>
                        <Icon as={tool.icon} className="w-8 h-8 text-cyan-400" />
                        <span className="text-sm font-medium text-gray-300 text-center">{tool.name}</span>
                    </div>
                ))}
            </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;