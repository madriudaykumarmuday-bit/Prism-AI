
# Prism AI - All-in-One AI Toolkit

[![Prism AI Logo](https://raw.githubusercontent.com/madriudaykumar/Prism-AI/main/public/logo.png)](https://github.com/madriudaykumar/Prism-AI)

**Prism AI** is a powerful and feature-rich web application that serves as a comprehensive AI-powered toolkit. Built with a sleek, modern interface, it goes far beyond a simple chatbot by integrating a full suite of specialized tools for creativity, productivity, education, and career development. The entire platform is powered by Google's advanced Gemini API.

This project was developed by **Madri Uday Kumar**.

---

## ✨ Features

Prism AI combines a core conversational chat experience with a powerful, modal-based **AI Tool Kit**.

### Core Chat Functionality
- **Conversational AI:** Engage in natural, human-like conversations on any topic.
- **Real-time Streaming:** Responses from the AI are streamed word-by-word for a dynamic experience.
- **Markdown & Code Rendering:** Full support for markdown formatting, including tables, lists, and syntax-highlighted code blocks with a "copy" button.
- **Multimodal Input:** Users can upload images to ask questions or provide context.
- **Voice Input:** A microphone button allows for voice-to-text transcription directly into the message input.
- **Web-Enhanced Search:** A toggle in the message bar allows the AI to access Google Search for up-to-date information, complete with source citations.
- **Multilingual Support:** Seamlessly switch between English and Telugu for AI responses.

### 🧰 The AI Tool Kit

A suite of powerful, single-purpose tools accessible from the main header:

#### Content & Creativity
- **Video Generator:** Generate short videos from a text prompt or animate a user-uploaded image.
- **Image Generator:** Create high-quality images from detailed text descriptions with various aspect ratios.
- **Logo Creator:** Generate four unique logo concepts based on a brand description, style, and color palette.
- **Presentation Generator:** Instantly create a structured, slide-by-slide presentation outline on any topic and download it as a **PowerPoint (.pptx)** or PDF file.
- **Course Creator:** Generates a complete course outline on any topic, using web search to find and link to relevant YouTube tutorials for each module.

#### Career & Education
- **Resume Builder:** A powerful two-pane resume editor with multiple templates ("Modern," "Classic," "Creative"). Features an "AI Enhance" button to rewrite job descriptions and exports to a print-ready PDF.
- **Interview Prep Hub:** Practice for job interviews with AI-generated quizzes on topics like Quantitative Aptitude and Logical Reasoning, complete with detailed explanations.
- **Student Success Hub:** Provides grade-level (1-10) and subject-specific quizzes for students, with answer reviews and a tool to find online learning resources.
- **Mindset Analyzer:** A comprehensive career tool that analyzes a user's quiz answers to generate a "Mindset Profile" and a personalized "Skill-Up Plan."
- **Learning Hub:** Generates a structured learning module on any topic.
- **Assessment Creator:** Creates a multiple-choice quiz from the chat context or content from the Learning Hub.

#### Development & Productivity
- **AI Code Runner:** An interactive IDE to write, **execute**, **debug**, and get AI-powered explanations for code in JavaScript, Python, and HTML.
- **Web Search Panel:** A dedicated side-panel for performing deep-dive web searches with sourced, clickable links and downloadable results.
- **Project Idea Generator:** Brainstorms a list of creative project ideas for any given topic or technology.

---

## 🛠️ Tech Stack

- **Core Framework:** [React](https://react.dev/) 19 & TypeScript
- **AI Engine:** [Google Gemini API](https://ai.google.dev/) via `@google/genai` SDK
  - Models: `gemini-2.5-flash` (text, reasoning), `imagen-4.0-generate-001` (images), `veo-2.0-generate-001` (video)
- **Styling:** [Tailwind CSS](https://tailwindcss.com/)
- **UI Components & Rendering:**
  - `react-markdown` & `remark-gfm` for rendering markdown content.
  - `react-syntax-highlighter` for beautiful code block syntax highlighting.
- **Browser APIs:** Web Speech API for voice input.
- **External Libraries (CDN):**
  - `pptxgenjs` for PowerPoint generation.
  - `jspdf` for PDF generation.

---

## 🚀 Getting Started

Follow these instructions to set up and run the project locally.

### Prerequisites
- A modern web browser (Chrome, Firefox, Safari).
- A valid **Google Gemini API Key**. You can get one from [Google AI Studio](https://aistudio.google.com/app/apikey).

### Installation
1.  **Clone the repository:**
    ```bash
    git clone https://github.com/madriudaykumar/Prism-AI.git
    cd Prism-AI
    ```

2.  **Set up your API Key:**
    - The application is configured to use an environment variable for the API key. In a local browser-based setup, you can simulate this by replacing the `process.env.API_KEY` placeholder.
    - **Open `services/geminiService.ts` and `hooks/useChat.ts`**.
    - Find every instance of `process.env.API_KEY` and replace it directly with your Gemini API key string.
      ```typescript
      // Before
      if (!process.env.API_KEY) { /* ... */ }
      export const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

      // After
      const myApiKey = "YOUR_GEMINI_API_KEY_HERE";
      if (!myApiKey) { /* ... */ }
      export const ai = new GoogleGenAI({ apiKey: myApiKey });
      ```
      > **Note:** Remember to do this in all required files and be careful not to commit your key to a public repository.

3.  **Run the application:**
    - Since this is a client-side project without a build step, you can simply open the `index.html` file in your browser.
    - For the best experience, use a local development server. If you have VS Code, the [Live Server](https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer) extension is a great option. Right-click `index.html` and choose "Open with Live Server".

---

## 🏗️ Project Structure

The project follows a standard component-based React structure.

```
/
├── components/         # All React components
│   ├── AI_TOOL_NAME.tsx  # Each AI tool has its own component file
│   ├── ChatWindow.tsx    # Displays the conversation
│   ├── CodeBlock.tsx     # Renders syntax-highlighted code
│   ├── Header.tsx        # Top navigation bar, manages tool modals
│   ├── LoginPage.tsx     # The welcome/login screen
│   ├── Message.tsx       # Renders a single chat message
│   ├── MessageInput.tsx  # The text input area
│   └── ...               # Other reusable components
│
├── hooks/              # Custom React hooks for stateful logic
│   ├── useChat.ts        # Manages chat state and API calls
│   └── useSpeechRecognition.ts # Encapsulates the Web Speech API
│
├── services/           # API interaction layer
│   └── geminiService.ts  # Centralizes all calls to the Gemini API
│
├── types.ts            # All TypeScript interfaces and type definitions
├── App.tsx             # Main application component, handles layout and state
├── index.html          # The main HTML entry point
└── index.tsx           # The React application root
```

---

## 🤝 Contributing

Contributions are welcome! If you have ideas for new features or improvements, feel free to fork the repository and submit a pull request.

1.  **Fork** the project.
2.  Create your feature branch (`git checkout -b feature/AmazingFeature`).
3.  Commit your changes (`git commit -m 'Add some AmazingFeature'`).
4.  Push to the branch (`git push origin feature/AmazingFeature`).
5.  Open a **Pull Request**.

---

## 📜 License

This project is licensed under the MIT License. See the `LICENSE` file for details.

---

## 🧑‍💻 Developed By

**Madri Uday Kumar**
```

