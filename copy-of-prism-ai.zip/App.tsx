
import React, { useState } from 'react';
import { ChatWindow } from './components/ChatWindow';
import { MessageInput } from './components/MessageInput';
import { useChat } from './hooks/useChat';
import { WelcomeScreen } from './components/WelcomeScreen';
import { Header } from './components/Header';
import { Language, MessageRole } from './types';
import LoginPage from './components/LoginPage';
import { Footer } from './components/Footer';

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [language, setLanguage] = useState<Language>('English');
  const [isWebSearchEnabled, setIsWebSearchEnabled] = useState(false);
  const { messages, sendMessage, isLoading, error } = useChat(language);

  const handleSend = (text: string, attachment: File | null) => {
    sendMessage(text, attachment, isWebSearchEnabled);
  };

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
  };

  const handleLogin = () => {
    setIsLoggedIn(true);
  };

  if (!isLoggedIn) {
    return <LoginPage onLogin={handleLogin} />;
  }

  const lastModelMessage = messages.slice().reverse().find(m => m.role === MessageRole.MODEL);
  const learningContext = lastModelMessage ? lastModelMessage.content : '';

  return (
    <div className="flex h-screen text-white font-sans">
      <div className="flex flex-col flex-grow min-w-0">
        <Header 
          currentLanguage={language} 
          onLanguageChange={handleLanguageChange} 
          learningContext={learningContext}
        />
        <main className="flex-grow flex flex-col overflow-hidden">
          {messages.length === 0 ? (
            <WelcomeScreen sendMessage={(prompt) => sendMessage(prompt, null, false)} />
          ) : (
            <ChatWindow messages={messages} isLoading={isLoading} />
          )}
          <div className="p-4 md:p-6 w-full max-w-4xl mx-auto flex-shrink-0">
            <MessageInput 
              onSend={handleSend} 
              disabled={isLoading}
              isWebSearchEnabled={isWebSearchEnabled}
              onWebSearchToggle={() => setIsWebSearchEnabled(prev => !prev)}
            />
            {error && <p className="text-red-500 text-sm mt-2 text-center">{error}</p>}
          </div>
        </main>
        <Footer />
      </div>
    </div>
  );
};

export default App;