
import { useState, useCallback, useEffect } from 'react';
// FIX: Use GenerateContentParameters instead of deprecated GenerateContentRequest.
import type { Part, Content, GenerateContentParameters } from '@google/genai';
import { ai } from '../services/geminiService';
import { ChatMessage, MessageRole, Language, GroundingChunk } from '../types';

const readAsBase64 = (file: File): Promise<string> => {
    return new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
};

const messageToContent = (msg: ChatMessage): Content => {
    const parts: Part[] = [];
    if (msg.attachment) {
        parts.push({
            inlineData: {
                data: msg.attachment.base64Data,
                mimeType: msg.attachment.mimeType,
            },
        });
    }
    if (msg.content) {
        parts.push({ text: msg.content });
    }
    // The API expects 'user' or 'model' roles.
    const role = msg.role === MessageRole.USER ? 'user' : 'model';
    return { role, parts };
};

// Helper function to handle real-time data queries on the client-side
const getRealTimeResponse = (text: string, language: Language): string | null => {
    const lowerText = text.toLowerCase().trim().replace(/[?.]/g, ''); // Clean up the input
    const now = new Date();

    // Create a function to get a date object with the year set to 2025
    const createModifiedDate = () => {
        const modifiedDate = new Date();
        modifiedDate.setFullYear(2025);
        return modifiedDate;
    };

    if (language === 'English') {
        const hasTime = /\b(time)\b/.test(lowerText);
        const hasDate = /\b(date|year)\b/.test(lowerText);
        const hasDay = /\b(day)\b/.test(lowerText);

        // Handle specific queries first
        if (hasTime && !hasDate && !hasDay) {
            return `The current time is ${now.toLocaleTimeString()}.`;
        }
        if (hasDate && !hasTime) {
            const modifiedDate = createModifiedDate();
            return `Today's date is ${modifiedDate.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}.`;
        }
        if (hasDay && !hasTime && !hasDate) {
            return `Today is ${now.toLocaleDateString(undefined, { weekday: 'long' })}.`;
        }
        // Catch-all if multiple keywords are present
        if (hasTime || hasDate || hasDay) {
            const modifiedDate = createModifiedDate();
            const dateString = modifiedDate.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
            const timeString = now.toLocaleTimeString();
            return `The current date and time is ${dateString}, ${timeString}.`;
        }
    } else if (language === 'Telugu') {
        const teluguLocale = 'te-IN';
        const hasTime = lowerText.includes('సమయం');
        const hasDate = lowerText.includes('తేది') || lowerText.includes('సంవత్సరం');
        const hasDay = lowerText.includes('రోజు');

        if (hasTime && !hasDate && !hasDay) {
            return `ప్రస్తుత సమయం ${now.toLocaleTimeString(teluguLocale)}.`;
        }
        if (hasDate && !hasTime) {
            const modifiedDate = createModifiedDate();
            return `ఈ రోజు తేది ${modifiedDate.toLocaleDateString(teluguLocale, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}.`;
        }
        if (hasDay && !hasTime && !hasDate) {
            return `ఈ రోజు ${now.toLocaleDateString(teluguLocale, { weekday: 'long' })}.`;
        }
        // Catch-all
        if (hasTime || hasDate || hasDay) {
            const modifiedDate = createModifiedDate();
            const dateString = modifiedDate.toLocaleDateString(teluguLocale, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
            const timeString = now.toLocaleTimeString(teluguLocale);
            return `ప్రస్తుత తేది మరియు సమయం ${dateString}, ${timeString}.`;
        }
    }

    return null; // Not a real-time query
};


export const useChat = (language: Language) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setMessages([]);
    setError(null);
  }, [language]);

  const sendMessage = useCallback(async (text: string, attachment: File | null, isWebSearchEnabled: boolean) => {
    if ((!text.trim() && !attachment)) return;
    
    setIsLoading(true);
    setError(null);

    let attachmentData;
    if (attachment) {
        try {
            const base64Data = await readAsBase64(attachment);
            attachmentData = {
                url: URL.createObjectURL(attachment),
                base64Data,
                mimeType: attachment.type,
            }
        } catch (e: any) {
            setError(`Failed to read attachment: ${e.message}`);
            setIsLoading(false);
            return;
        }
    }

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: MessageRole.USER,
      content: text,
      ...(attachmentData && { attachment: attachmentData })
    };

    // Check for real-time queries before calling the API
    const realTimeResponse = getRealTimeResponse(text, language);
    if (realTimeResponse) {
        setMessages(prev => [...prev, userMessage]);
        const modelMessage: ChatMessage = {
            id: (Date.now() + 1).toString(),
            role: MessageRole.MODEL,
            content: realTimeResponse,
        };
        // Simulate a quick response
        setTimeout(() => {
            setMessages(prev => [...prev, modelMessage]);
            setIsLoading(false);
        }, 300);
        return; // Bypass the API call
    }


    const modelMessageId = (Date.now() + 1).toString();
    const modelMessagePlaceholder: ChatMessage = {
        id: modelMessageId,
        role: MessageRole.MODEL,
        content: '',
    };
    
    setMessages(prev => [...prev, userMessage, modelMessagePlaceholder]);
    
    try {
      const history = messages.map(messageToContent);
      
      let systemInstruction = {
        'English': 'You are a helpful and professional AI assistant. Format your responses using markdown. When asked about your name or who created you, your required response is: "I am Prism AI, I was trained by my boss M Uday Kumar."',
        'Telugu': 'మీరు సహాయకారి మరియు వృత్తిపరమైన AI అసిస్టెంట్. మీ ప్రతిస్పందనలను మార్క్‌డౌన్ ఉపయోగించి ఫార్మాట్ చేయండి. మీ పేరు లేదా మిమ్మల్ని ఎవరు సృష్టించారు అని అడిగినప్పుడు, మీ అవసరమైన ప్రతిస్పందన: "నేను ప్రిజం AI, నాకు మా బాస్, ఎం ఉదయ్ కుమార్ శిక్షణ ఇచ్చారు."'
      }[language];

      if (isWebSearchEnabled) {
          const webSearchInstruction = {
            'English': "\n\nYou are also a web search expert. If the user asks for information that could be on YouTube (like tutorials, reviews, creators), prioritize finding and citing YouTube sources.",
            'Telugu': "\n\nమీరు వెబ్ శోధన నిపుణులు కూడా. వినియోగదారు ట్యుటోరియల్స్, రివ్యూలు, సృష్టికర్తల వంటి YouTubeలో ఉండే సమాచారం కోసం అడిగితే, YouTube ఆధారాలను కనుగొని ఉదహరించడానికి ప్రాధాన్యత ఇవ్వండి."
          }[language];
          systemInstruction += webSearchInstruction;
      }
      
      const request: GenerateContentParameters = {
        model: 'gemini-2.5-flash',
        contents: [...history, messageToContent(userMessage)],
        config: {
          systemInstruction: systemInstruction,
          ...(isWebSearchEnabled && { tools: [{ googleSearch: {} }] })
        }
      };

      const stream = await ai.models.generateContentStream(request);
      
      let accumulatedContent = '';
      let accumulatedChunks: GroundingChunk[] = [];
      for await (const chunk of stream) {
        accumulatedContent += chunk.text;
        
        const chunkGroundingMetadata = chunk.candidates?.[0]?.groundingMetadata;
        if (chunkGroundingMetadata?.groundingChunks) {
            accumulatedChunks.push(...(chunkGroundingMetadata.groundingChunks as GroundingChunk[]));
        }

        setMessages(prev =>
          prev.map(msg =>
            msg.id === modelMessageId 
            ? { 
                ...msg, 
                content: accumulatedContent, 
                groundingChunks: accumulatedChunks.length > 0 ? [...new Set(accumulatedChunks)] : undefined 
              } 
            : msg
          )
        );
      }
      
    } catch (e: any) {
      console.error(e);
      const errorMessage = `Failed to get response. Please try again. Error: ${e.message}`;
      setError(errorMessage);
       setMessages(prev =>
          prev.map(msg =>
            msg.id === modelMessageId ? { ...msg, content: errorMessage } : msg
          )
        );
    } finally {
      setIsLoading(false);
    }
  }, [messages, language]);

  return { messages, sendMessage, isLoading, error };
};
